"""app/api/health.py"""

import logging
from fastapi import APIRouter, Response
from app.db.session import check_db_health
from app.config.registry import get_loader, get_watcher
from app.logging.setup import get_splunk_handler

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/health")
async def liveness():
    return {"status": "ok"}


@router.get("/health/db")
async def readiness(response: Response):
    result = await check_db_health()
    if result["status"] != "ok":
        response.status_code = 503
    return result


@router.get("/health/full")
async def full_health():
    db      = await check_db_health()
    loader  = get_loader()
    watcher = get_watcher()

    cache       = loader.cache_info
    config_ok   = cache.get("loaded") and not cache.get("stale", False)

    splunk = None
    h = get_splunk_handler()
    if h:
        s = h.stats
        splunk = {
            "active": True,
            "queue_depth": h.queue_depth,
            "events_shipped": s.events_shipped,
            "events_dropped": s.events_dropped,
            "last_error": s.last_error,
        }
    else:
        splunk = {"active": False}

    return {
        "status":  "ok" if db["status"] == "ok" and config_ok else "degraded",
        "database": db,
        "config": {
            "loader":  cache,
            "watcher": watcher.status if watcher else {"active": False},
        },
        "splunk": splunk,
    }
