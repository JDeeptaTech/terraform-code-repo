"""
app/config/github_loader.py
────────────────────────────
GitHub config loader with dynamic ref switching.

Enhanced from previous version to support:
  - set_ref()  : switch to a new tag/branch/SHA without restart
  - Promotion history  : last N promotions logged
  - ETag caching per ref
  - Concurrent refresh protection (asyncio.Lock)
"""

from __future__ import annotations

import asyncio
import base64
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, List, Optional

import httpx

from app.config.schema import PlacementConfig, parse_config

logger = logging.getLogger(__name__)


@dataclass
class CachedConfig:
    config:     PlacementConfig
    raw:        str
    sha:        str
    ref:        str        # which ref this was fetched from
    fetched_at: float
    etag:       Optional[str] = None


@dataclass
class PromotionRecord:
    previous_ref: Optional[str]
    current_ref:  str
    sha:          str
    reason:       str
    timestamp:    float = field(default_factory=time.time)


class GitHubConfigLoader:
    """
    Async GitHub config loader.

    Key addition over previous version:
      set_ref(ref, reason) — atomically switches the active ref and
      triggers an immediate reload. Called by ReleaseWatcher on promotion.
    """

    GITHUB_API = "https://api.github.com"

    def __init__(
        self,
        owner:            str,
        repo:             str,
        path:             str,
        ref:              str = "main",
        token:            Optional[str] = None,
        ttl:              int = 60,
        refresh_interval: int = 60,
        on_change:        Optional[Callable[[PlacementConfig, str], Awaitable[None]]] = None,
    ):
        self._owner    = owner
        self._repo     = repo
        self._path     = path.lstrip("/")
        self._ref      = ref           # current active ref (mutable)
        self._ttl      = ttl
        self._interval = refresh_interval
        self._on_change = on_change

        self._cache:  Optional[CachedConfig]   = None
        self._lock:   asyncio.Lock             = asyncio.Lock()
        self._task:   Optional[asyncio.Task]   = None
        self._promotions: List[PromotionRecord] = []

        headers = {
            "Accept":               "application/vnd.github.v3+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"

        self._client = httpx.AsyncClient(
            base_url=self.GITHUB_API,
            headers=headers,
            timeout=httpx.Timeout(connect=5.0, read=10.0, write=5.0, pool=5.0),
        )

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        logger.info(
            "GitHubConfigLoader starting",
            extra={"repo": f"{self._owner}/{self._repo}", "path": self._path, "ref": self._ref},
        )
        await self.refresh(force=True)
        self._task = asyncio.create_task(self._bg_refresh(), name="github-config-refresh")

    async def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self._client.aclose()
        logger.info("GitHubConfigLoader stopped")

    # ── Public interface ───────────────────────────────────────────────────────

    async def get(self) -> PlacementConfig:
        """Return cached config, refreshing if TTL expired."""
        if self._cache is None:
            await self.refresh(force=True)
        elif self._ttl > 0:
            age = time.monotonic() - self._cache.fetched_at
            if age > self._ttl:
                await self.refresh()
        return self._cache.config

    async def set_ref(self, new_ref: str, reason: str = "promotion") -> bool:
        """
        Switch to a new ref (tag, branch, or SHA) and reload immediately.
        Called by ReleaseWatcher when a new release/tag is discovered.
        Returns True if config content actually changed.
        """
        previous_ref = self._ref

        logger.info(
            "Switching config ref",
            extra={"previous": previous_ref, "new": new_ref, "reason": reason},
        )

        self._ref = new_ref
        changed = await self.refresh(force=True)

        self._promotions.append(PromotionRecord(
            previous_ref=previous_ref,
            current_ref=new_ref,
            sha=self._cache.sha[:8] if self._cache else "unknown",
            reason=reason,
        ))

        # Keep last 50 promotion records
        if len(self._promotions) > 50:
            self._promotions = self._promotions[-50:]

        return changed

    async def refresh(self, force: bool = False) -> bool:
        """
        Fetch config from GitHub for the current active ref.
        Returns True if config content changed.
        """
        async with self._lock:
            try:
                raw, sha, etag = await self._fetch()
            except Exception as exc:
                logger.error("GitHub fetch failed: %s", exc, exc_info=True)
                if self._cache:
                    logger.warning("Using stale cached config (ref=%s)", self._ref)
                    return False
                raise RuntimeError(f"No cached config and GitHub fetch failed: {exc}") from exc

            # SHA check — skip if same content on same ref
            if not force and self._cache and self._cache.sha == sha and self._cache.ref == self._ref:
                logger.debug("Config unchanged (sha=%s ref=%s)", sha[:8], self._ref)
                self._cache.fetched_at = time.monotonic()
                return False

            try:
                new_config = parse_config(raw, source_path=self._path)
            except Exception as exc:
                logger.error("Config parse error (ref=%s sha=%s): %s", self._ref, sha[:8], exc)
                return False

            previous_sha = self._cache.sha[:8] if self._cache else "none"
            self._cache = CachedConfig(
                config=new_config,
                raw=raw,
                sha=sha,
                ref=self._ref,
                fetched_at=time.monotonic(),
                etag=etag,
            )

            logger.info(
                "Config loaded",
                extra={"sha": sha[:8], "previous_sha": previous_sha, "ref": self._ref},
            )

            if self._on_change and previous_sha != "none":
                try:
                    await self._on_change(new_config, self._ref)
                except Exception as exc:
                    logger.error("on_change callback error: %s", exc)

            return True

    @property
    def active_ref(self) -> str:
        return self._ref

    @property
    def promotion_history(self) -> List[PromotionRecord]:
        return list(self._promotions)

    @property
    def cache_info(self) -> dict:
        if not self._cache:
            return {"loaded": False}
        age = time.monotonic() - self._cache.fetched_at
        return {
            "loaded":      True,
            "ref":         self._cache.ref,
            "sha":         self._cache.sha[:8],
            "age_seconds": round(age, 1),
            "ttl_seconds": self._ttl,
            "stale":       age > self._ttl,
            "repo":        f"{self._owner}/{self._repo}",
            "path":        self._path,
        }

    # ── Internal ───────────────────────────────────────────────────────────────

    async def _fetch(self) -> tuple[str, str, Optional[str]]:
        """Fetch file content from GitHub Contents API for current active ref."""
        url     = f"/repos/{self._owner}/{self._repo}/contents/{self._path}"
        params  = {"ref": self._ref}
        headers = {}

        # Conditional ETag — only valid for same ref
        if self._cache and self._cache.etag and self._cache.ref == self._ref:
            headers["If-None-Match"] = self._cache.etag

        response = await self._client.get(url, params=params, headers=headers)

        if response.status_code == 304:
            return self._cache.raw, self._cache.sha, self._cache.etag

        if response.status_code == 404:
            raise FileNotFoundError(
                f"Config not found: {self._owner}/{self._repo}/{self._path}@{self._ref}"
            )
        if response.status_code == 401:
            raise PermissionError("GitHub API: invalid or expired token")
        if response.status_code == 403:
            reset = response.headers.get("X-RateLimit-Reset", "unknown")
            remaining = response.headers.get("X-RateLimit-Remaining", "?")
            raise PermissionError(
                f"GitHub API rate limited (remaining={remaining}, resets={reset})"
            )

        response.raise_for_status()
        data    = response.json()
        sha     = data["sha"]
        etag    = response.headers.get("ETag")
        content = base64.b64decode(data["content"]).decode("utf-8")
        return content, sha, etag

    async def _bg_refresh(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._interval)
                changed = await self.refresh()
                if changed:
                    logger.info("Background refresh: config updated (ref=%s)", self._ref)
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.error("Background refresh error: %s", exc)
