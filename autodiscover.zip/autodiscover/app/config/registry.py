"""
app/config/registry.py
───────────────────────
Singleton registry for the config loader and release watcher.
"""

import logging
from typing import Optional

from app.config.github_loader import GitHubConfigLoader
from app.config.release_watcher import ReleaseWatcher
from app.config.schema import PlacementConfig

logger = logging.getLogger(__name__)

_loader:  Optional[GitHubConfigLoader] = None
_watcher: Optional[ReleaseWatcher]     = None


def init(loader: GitHubConfigLoader, watcher: Optional[ReleaseWatcher] = None) -> None:
    global _loader, _watcher
    _loader  = loader
    _watcher = watcher


def get_loader() -> GitHubConfigLoader:
    if not _loader:
        raise RuntimeError("GitHubConfigLoader not initialised")
    return _loader


def get_watcher() -> Optional[ReleaseWatcher]:
    return _watcher


async def get_placement_config() -> PlacementConfig:
    """FastAPI dependency — returns current in-memory config."""
    return await get_loader().get()
