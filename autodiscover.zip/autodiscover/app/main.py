"""
app/main.py
────────────
FastAPI lifespan wires:
  1. Logging
  2. ReleaseWatcher  (discovers best tag/release)
       │ on_promote ──► loader.set_ref(new_ref)
  3. GitHubConfigLoader  (fetches + caches config for the active ref)
  4. DB tables
  5. Middleware + routers
"""

import logging
import logging as stdlib_logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.settings import settings
from app.config.release_watcher import ReleaseWatcher, ConfigStrategy, PromotionEvent
from app.config.github_loader import GitHubConfigLoader
from app.config.schema import PlacementConfig
from app.config import registry
from app.logging.setup import setup_logging
from app.middleware.logging_middleware import RequestLoggingMiddleware
from app.db.session import engine, dispose_engine
from app.db import models as db_models

logger = logging.getLogger(__name__)


# ── Callbacks ──────────────────────────────────────────────────────────────────

async def _on_promotion(event: PromotionEvent) -> None:
    """
    Called by ReleaseWatcher when a better ref is found.
    Switches the loader to the new ref and triggers a reload.
    """
    logger.warning(
        "Config promotion: switching ref",
        extra={
            "previous": str(event.previous),
            "current":  str(event.current),
            "reason":   event.reason,
            "strategy": event.strategy,
        },
    )
    loader = registry.get_loader()
    await loader.set_ref(event.current.name, reason=event.reason)


async def _on_config_change(new_config: PlacementConfig, ref: str) -> None:
    """Called by GitHubConfigLoader when config file content changes."""
    logger.warning(
        "Config content changed",
        extra={
            "ref":         ref,
            "version":     new_config.version,
            "environments": list(new_config.environments.keys()),
        },
    )


# ── Lifespan ───────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):

    # ── 1. Logging ─────────────────────────────────────────────────────────────
    setup_logging()
    logger.info("Starting placement-engine", extra={
        "env": settings.app_env,
        "version": settings.app_version,
        "config_strategy": settings.github_config_strategy.value,
    })

    # ── 2. Release watcher ─────────────────────────────────────────────────────
    use_watcher = settings.github_config_strategy not in (
        ConfigStrategy.TRACK_BRANCH,
        ConfigStrategy.PINNED,
    )

    watcher: ReleaseWatcher | None = None
    initial_ref = settings.github_ref   # fallback

    if use_watcher:
        watcher = ReleaseWatcher(
            owner            = settings.github_owner,
            repo             = settings.github_repo,
            strategy         = settings.github_config_strategy,
            semver_range     = settings.github_semver_range,
            allow_prerelease = settings.github_allow_prerelease,
            poll_interval    = settings.release_poll_interval,
            token            = settings.github_token,
            on_promote       = _on_promotion,
        )
        # Discover best initial ref BEFORE starting the loader
        initial_ref_obj = await watcher.start()
        initial_ref     = initial_ref_obj.name
        logger.info("Initial ref selected by watcher: %s", initial_ref)
    else:
        logger.info("Using static ref: %s (strategy=%s)",
                    initial_ref, settings.github_config_strategy.value)

    # ── 3. Config loader ────────────────────────────────────────────────────────
    loader = GitHubConfigLoader(
        owner            = settings.github_owner,
        repo             = settings.github_repo,
        path             = settings.github_config_path,
        ref              = initial_ref,
        token            = settings.github_token,
        ttl              = settings.config_ttl,
        refresh_interval = settings.config_refresh_interval,
        on_change        = _on_config_change,
    )

    registry.init(loader, watcher)
    await loader.start()

    # ── 4. DB ──────────────────────────────────────────────────────────────────
    async with engine.begin() as conn:
        await conn.run_sync(db_models.Base.metadata.create_all)
    logger.info("DB ready")

    yield

    # ── Shutdown ────────────────────────────────────────────────────────────────
    logger.info("Shutting down placement-engine")
    if watcher:
        await watcher.stop()
    await loader.stop()
    await dispose_engine()
    stdlib_logging.shutdown()


# ── App factory ────────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="Placement Decision Engine",
        version=settings.app_version,
        docs_url="/docs" if settings.app_env != "production" else None,
        redoc_url=None,
        lifespan=lifespan,
    )

    app.add_middleware(CORSMiddleware,
        allow_origins=["*"], allow_methods=["*"],
        allow_headers=["*"], expose_headers=["X-Request-ID"])
    app.add_middleware(RequestLoggingMiddleware)

    @app.exception_handler(Exception)
    async def _eh(request: Request, exc: Exception):
        logger.error("Unhandled exception", extra={"error": str(exc)}, exc_info=True)
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})

    from app.api.health    import router as health_router
    from app.api.placement import router as placement_router
    from app.api.config    import router as config_router

    app.include_router(health_router,    prefix="/v1",           tags=["Health"])
    app.include_router(placement_router, prefix="/v1/placement", tags=["Placement"])
    app.include_router(config_router,    prefix="/v1/config",    tags=["Config"])

    return app


app = create_app()
