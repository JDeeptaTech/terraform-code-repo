"""app/settings.py — all application settings."""

from typing import Optional
from pydantic_settings import BaseSettings
from app.config.release_watcher import ConfigStrategy


class Settings(BaseSettings):

    # ── App ────────────────────────────────────────────────────────────────────
    app_env:     str = "development"
    app_version: str = "1.0.0"
    log_level:   str = "INFO"

    # ── Database ───────────────────────────────────────────────────────────────
    database_url: str = (
        "postgresql+asyncpg://placement:placement@localhost:5432/placement_engine"
    )

    # ── GitHub — repo ──────────────────────────────────────────────────────────
    github_owner:       str           = "my-org"
    github_repo:        str           = "platform-config"
    github_config_path: str           = "placement/config.yaml"
    github_token:       Optional[str] = None
    github_webhook_secret: Optional[str] = None

    # ── GitHub — version / auto-discovery strategy ─────────────────────────────
    #
    # GITHUB_CONFIG_STRATEGY controls how the active ref is selected:
    #
    #   latest_release  Track latest published GitHub Release (default).
    #                   Set GITHUB_ALLOW_PRERELEASE=true to include pre-releases.
    #
    #   semver_range    Track highest tag matching GITHUB_SEMVER_RANGE.
    #                   Example: ">=1.0.0 <2.0.0"
    #
    #   track_branch    Track HEAD of GITHUB_REF branch.
    #                   Every push is picked up — no versioning.
    #
    #   pinned          Fixed to GITHUB_REF. No auto-discovery.
    #                   Promote manually via POST /v1/config/promote.
    #
    github_config_strategy: ConfigStrategy = ConfigStrategy.LATEST_RELEASE
    github_ref:             str            = "main"     # used by track_branch + pinned
    github_semver_range:    str            = ""         # used by semver_range
    github_allow_prerelease: bool          = False

    # ── GitHub — polling ───────────────────────────────────────────────────────
    config_ttl:              int = 60    # loader: seconds before passive re-fetch
    config_refresh_interval: int = 60   # loader: background refresh poll
    release_poll_interval:   int = 300  # watcher: check for new releases (0=webhook-only)

    # ── Splunk ─────────────────────────────────────────────────────────────────
    splunk_hec_url:    Optional[str] = None
    splunk_hec_token:  Optional[str] = None
    splunk_index:      str           = "main"
    splunk_source:     str           = "placement-engine"
    splunk_verify_ssl: bool          = True

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


settings = Settings()
