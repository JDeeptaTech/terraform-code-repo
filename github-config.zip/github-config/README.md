# Placement Engine — GitHub-backed Config

Config-as-code: placement policy (tag rules, scoring weights, environment constraints)
lives in a GitHub repo. No database needed for config — only for inventory (clusters, networks, datastores).

---

## How It Works

```
GitHub repo (platform-config)
  └── placement/config.yaml   ← tag rules, scoring, environments
            │
            │  GitHub Contents API (httpx async)
            │  ETag caching + SHA change detection
            ▼
  GitHubConfigLoader (per pod)
    ├── In-memory cache (TTL=60s)
    ├── Background refresh task (asyncio, every 60s)
    └── Webhook endpoint (POST /v1/config/refresh)
            │
            ▼
  FastAPI Depends(get_placement_config)
    └── merge_selectors(env, workload_type)
            │
            ▼
  Placement decision engine
```

---

## Config File (in GitHub repo)

Location: `placement/config.yaml` in your config repo.

Structure:
```yaml
version: "1.0"
scoring:
  weights: { compute: 0.50, network: 0.25, datastore: 0.25 }
defaults:
  strategy: best_fit
  ha_required: true
environments:
  prod:
    cluster_tags:  { must_have: ["prod"], exclude: ["maintenance"] }
    network_tags:  { must_have: ["vlan-prod"] }
    datastore_tags: { must_have: ["prod-storage"], any_of: ["nvme","ssd"] }
    datastore_constraints: { min_free_gb: 100, min_free_percent: 15.0 }
workload_profiles:
  gpu:
    cluster_tags: { any_of: ["gpu-enabled"] }
```

See `github-repo-example/placement/config.yaml` for the full example.

---

## API Request — Simplified

Tag selectors are now resolved server-side from config. Request body is just:

```json
{
  "workload": {
    "name":          "finance-db-vm",
    "cpu_cores":     8,
    "memory_gb":     64,
    "disk_gb":       500,
    "workload_type": "memory_intensive"
  },
  "environment": "prod",
  "strategy":    null,
  "top_n":       3
}
```

The engine resolves merged selectors from:
- `environments.prod` (base tag rules)
- `workload_profiles.memory_intensive` (type-specific additions, merged on top)

---

## Tag Merge Order

```
environments.<env>           workload_profiles.<type>
  cluster_tags.must_have  ─┐
  cluster_tags.any_of     ─┤  UNION  →  merged cluster_must_have
  cluster_tags.exclude    ─┘            merged cluster_any_of
  cluster_prefer_tags     ─┐            merged cluster_exclude
                            ┤  UNION  →  merged cluster_prefer
  workload_profiles.*     ─┘
```

Exclusions always accumulate — if either source excludes a tag, it's excluded.

---

## Config Reload Triggers

| Trigger | How | Latency |
|---------|-----|---------|
| TTL expiry | Passive — checked on next request | Up to `CONFIG_TTL` seconds |
| Background task | Polls every `CONFIG_REFRESH_INTERVAL` seconds | Up to 60s |
| GitHub webhook | Push event → POST `/v1/config/refresh` | ~1s |
| Manual | `POST /v1/config/refresh` with `X-Manual-Refresh: true` | ~1s |

**Recommended**: Set up the GitHub webhook for near-instant config propagation.

---

## GitHub Webhook Setup

1. Go to your config repo → Settings → Webhooks → Add webhook
2. Payload URL: `https://your-app/v1/config/refresh`
3. Content type: `application/json`
4. Secret: same value as `GITHUB_WEBHOOK_SECRET` env var
5. Events: select "Push"

---

## GitHub Token (PAT) Setup

Create a fine-grained PAT with **minimum permissions**:
- Repository: `platform-config` only
- Permission: `Contents: Read`

Set as `GITHUB_TOKEN` env var / K8s secret.

---

## Config Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET`  | `/v1/config/current` | Active config in memory |
| `GET`  | `/v1/config/status`  | Cache SHA, age, staleness |
| `POST` | `/v1/config/refresh` | Force reload from GitHub |
| `GET`  | `/v1/health/full`    | Includes config cache status |

---

## Kubernetes — GitHub-specific Notes

`initialDelaySeconds` on startup probe is 90s (18 × 5s) to allow time for:
- Gunicorn to fork workers
- Each worker to complete the initial GitHub API fetch
- Handle GitHub API rate limits or temporary slowness

The `GITHUB_TOKEN` secret gives 5,000 API requests/hour (vs 60 unauthenticated).
With ETag conditional requests, most fetches return 304 Not Modified (doesn't count toward rate limit).

---

## Running Tests

```bash
pip install -r requirements.txt
pytest tests/ -v
```
