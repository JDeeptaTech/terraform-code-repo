"""
app/config/registry.py
───────────────────────
Singleton registry that holds the GitHubConfigLoader instance.

Provides:
  - get_placement_config()  FastAPI dependency — returns current config
  - get_loader()            Access the loader for health checks / manual refresh

The loader is initialised once in app lifespan (main.py) and stored here
so it's accessible across the entire application without circular imports.
"""

import logging
from typing import Optional
from app.config.github_loader import GitHubConfigLoader
from app.config.schema import PlacementConfig

logger = logging.getLogger(__name__)

_loader: Optional[GitHubConfigLoader] = None


def init_loader(loader: GitHubConfigLoader) -> None:
    """Called once from FastAPI lifespan startup."""
    global _loader
    _loader = loader


def get_loader() -> GitHubConfigLoader:
    if _loader is None:
        raise RuntimeError("GitHubConfigLoader not initialised — call init_loader() first")
    return _loader


# ── FastAPI dependency ─────────────────────────────────────────────────────────

async def get_placement_config() -> PlacementConfig:
    """
    FastAPI dependency that returns the current placement config.

    Usage:
        @router.post("/decide")
        async def decide(
            request: PlacementRequest,
            config: PlacementConfig = Depends(get_placement_config),
        ):
            selectors = config.merge_selectors(
                env=request.environment,
                workload_type=request.workload.workload_type,
            )
            ...

    Returns cached config — does NOT hit GitHub on every request.
    TTL-based refresh happens in background task.
    """
    return await get_loader().get()
