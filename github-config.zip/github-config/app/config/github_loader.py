"""
app/config/github_loader.py
────────────────────────────
Loads placement engine configuration from a GitHub repository.

Architecture:
  ┌─────────────────────────────────────────────────────────────┐
  │                    GitHubConfigLoader                        │
  │                                                             │
  │  fetch()  ──► GitHub API  ──► parse YAML/JSON              │
  │     │                                                       │
  │     └──► in-memory cache (TTL based)                       │
  │               │                                             │
  │               └──► background refresh task (asyncio)       │
  │                                                             │
  │  on_change callbacks ──► notify FastAPI app                │
  └─────────────────────────────────────────────────────────────┘

Supported config file formats in GitHub repo:
  config/placement.yaml    (recommended)
  config/placement.json

Refresh triggers:
  1. TTL expiry          (default: 60s)       — passive poll
  2. GitHub webhook      POST /v1/config/refresh  — instant push
  3. Manual             await loader.refresh()

GitHub API authentication:
  GITHUB_TOKEN  — fine-grained PAT with "contents: read" on the config repo
                  (no token = 60 req/hr unauthenticated; with token = 5000/hr)
"""

import asyncio
import base64
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, Optional

import httpx

from app.config.schema import PlacementConfig, parse_config

logger = logging.getLogger(__name__)


# ── Config cache entry ─────────────────────────────────────────────────────────

@dataclass
class CachedConfig:
    config:     PlacementConfig
    raw:        str               # original YAML/JSON string
    sha:        str               # GitHub blob SHA — used for change detection
    fetched_at: float             # time.monotonic() timestamp
    etag:       Optional[str] = None


# ── Loader ─────────────────────────────────────────────────────────────────────

class GitHubConfigLoader:
    """
    Async GitHub config loader with in-memory cache and background refresh.

    Parameters
    ----------
    owner           GitHub org or user  e.g. "my-org"
    repo            Repository name     e.g. "platform-config"
    path            Path to config file e.g. "placement/config.yaml"
    ref             Branch / tag / SHA  e.g. "main"
    token           GitHub PAT (fine-grained, contents:read)
    ttl             Cache TTL in seconds (0 = always fetch)
    refresh_interval Background refresh interval in seconds
    on_change       Optional async callback called when config changes
    """

    GITHUB_API = "https://api.github.com"

    def __init__(
        self,
        owner:            str,
        repo:             str,
        path:             str,
        ref:              str = "main",
        token:            Optional[str] = None,
        ttl:              int = 60,
        refresh_interval: int = 60,
        on_change:        Optional[Callable[[PlacementConfig], Awaitable[None]]] = None,
    ):
        self._owner    = owner
        self._repo     = repo
        self._path     = path.lstrip("/")
        self._ref      = ref
        self._ttl      = ttl
        self._interval = refresh_interval
        self._on_change = on_change

        self._cache:  Optional[CachedConfig] = None
        self._lock  = asyncio.Lock()
        self._task:  Optional[asyncio.Task] = None

        # Build HTTP client with auth + timeouts
        headers = {
            "Accept":               "application/vnd.github.v3+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"

        self._client = httpx.AsyncClient(
            base_url=self.GITHUB_API,
            headers=headers,
            timeout=httpx.Timeout(connect=5.0, read=10.0, write=5.0, pool=5.0),
        )

    # ── Public interface ───────────────────────────────────────────────────────

    async def start(self) -> None:
        """
        Initial fetch + start background refresh task.
        Call from FastAPI lifespan startup.
        """
        logger.info(
            "GitHubConfigLoader starting",
            extra={
                "repo":  f"{self._owner}/{self._repo}",
                "path":  self._path,
                "ref":   self._ref,
                "ttl":   self._ttl,
            },
        )
        await self.refresh(force=True)
        self._task = asyncio.create_task(
            self._background_refresh(),
            name="github-config-refresh",
        )

    async def stop(self) -> None:
        """Cancel background task and close HTTP client. Call from lifespan shutdown."""
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self._client.aclose()
        logger.info("GitHubConfigLoader stopped")

    async def get(self) -> PlacementConfig:
        """
        Return cached config, refreshing if TTL has expired.
        Fast path: returns cached value in O(1) if still fresh.
        """
        if self._cache is None:
            await self.refresh(force=True)

        elif self._ttl > 0:
            age = time.monotonic() - self._cache.fetched_at
            if age > self._ttl:
                logger.debug("Config TTL expired (age=%.1fs), refreshing", age)
                await self.refresh()

        return self._cache.config

    async def refresh(self, force: bool = False) -> bool:
        """
        Fetch config from GitHub.

        Uses SHA comparison to detect actual content changes —
        avoids unnecessary re-parsing and callback invocations.

        Returns True if config changed, False if unchanged.
        """
        async with self._lock:
            try:
                raw, sha, etag = await self._fetch_from_github()
            except Exception as exc:
                logger.error(
                    "Failed to fetch config from GitHub",
                    extra={"error": str(exc)},
                    exc_info=True,
                )
                if self._cache:
                    logger.warning("Using stale cached config due to fetch error")
                    return False
                raise RuntimeError(
                    f"No cached config and GitHub fetch failed: {exc}"
                ) from exc

            # ── Change detection via SHA ──────────────────────────────────────
            if not force and self._cache and self._cache.sha == sha:
                logger.debug("Config SHA unchanged (%s), skipping reload", sha[:8])
                self._cache.fetched_at = time.monotonic()   # reset TTL
                return False

            # ── Parse new config ──────────────────────────────────────────────
            try:
                new_config = parse_config(raw, source_path=self._path)
            except Exception as exc:
                logger.error(
                    "Config parse error — keeping existing config",
                    extra={"sha": sha[:8], "error": str(exc)},
                )
                return False

            previous_sha = self._cache.sha[:8] if self._cache else "none"
            self._cache = CachedConfig(
                config=new_config,
                raw=raw,
                sha=sha,
                fetched_at=time.monotonic(),
                etag=etag,
            )

            logger.info(
                "Config loaded from GitHub",
                extra={
                    "sha":          sha[:8],
                    "previous_sha": previous_sha,
                    "path":         self._path,
                    "ref":          self._ref,
                    "changed":      previous_sha != sha[:8],
                },
            )

            # ── Notify listeners ──────────────────────────────────────────────
            if self._on_change and previous_sha != "none":
                try:
                    await self._on_change(new_config)
                except Exception as exc:
                    logger.error("on_change callback error: %s", exc)

            return True

    @property
    def cache_info(self) -> dict:
        """Diagnostics — exposed via /v1/health/full and /v1/config/status."""
        if not self._cache:
            return {"loaded": False}
        age = time.monotonic() - self._cache.fetched_at
        return {
            "loaded":      True,
            "sha":         self._cache.sha[:8],
            "age_seconds": round(age, 1),
            "ttl_seconds": self._ttl,
            "stale":       age > self._ttl,
            "repo":        f"{self._owner}/{self._repo}",
            "path":        self._path,
            "ref":         self._ref,
        }

    # ── Internal ───────────────────────────────────────────────────────────────

    async def _fetch_from_github(self) -> tuple[str, str, Optional[str]]:
        """
        Fetch file content via GitHub Contents API.

        Returns (raw_content, sha, etag).

        GitHub Contents API response:
          {
            "content":  "<base64-encoded content>",
            "sha":      "<blob SHA>",
            "encoding": "base64"
          }
        """
        url = f"/repos/{self._owner}/{self._repo}/contents/{self._path}"
        params = {"ref": self._ref}

        # Conditional request — skip if ETag matches (304 Not Modified)
        headers = {}
        if self._cache and self._cache.etag:
            headers["If-None-Match"] = self._cache.etag

        response = await self._client.get(url, params=params, headers=headers)

        if response.status_code == 304:
            # Not modified — return cached values
            logger.debug("GitHub returned 304 Not Modified")
            return self._cache.raw, self._cache.sha, self._cache.etag

        if response.status_code == 404:
            raise FileNotFoundError(
                f"Config file not found: {self._owner}/{self._repo}/{self._path}@{self._ref}"
            )

        if response.status_code == 401:
            raise PermissionError("GitHub API: invalid or expired token")

        if response.status_code == 403:
            reset = response.headers.get("X-RateLimit-Reset", "unknown")
            raise PermissionError(f"GitHub API rate limit exceeded. Resets at: {reset}")

        response.raise_for_status()

        data    = response.json()
        sha     = data["sha"]
        etag    = response.headers.get("ETag")
        content = base64.b64decode(data["content"]).decode("utf-8")

        return content, sha, etag

    async def _background_refresh(self) -> None:
        """Periodically refresh config in the background."""
        while True:
            try:
                await asyncio.sleep(self._interval)
                changed = await self.refresh()
                if changed:
                    logger.info("Background refresh: config updated")
                else:
                    logger.debug("Background refresh: config unchanged")
            except asyncio.CancelledError:
                logger.info("Background config refresh task cancelled")
                return
            except Exception as exc:
                logger.error("Background config refresh error: %s", exc)
                # Don't crash the task — retry on next interval
