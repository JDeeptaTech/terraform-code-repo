"""
app/main.py
────────────
FastAPI application factory.

Startup order:
  1. setup_logging()
  2. GitHubConfigLoader.start()   ← initial fetch + background refresh task
  3. DB tables created
  4. Middleware registered
  5. Routers mounted

Shutdown order:
  1. GitHubConfigLoader.stop()    ← cancel background task
  2. dispose_engine()             ← drain DB pool
  3. logging.shutdown()           ← flush Splunk HEC queue
"""

import logging
import logging as stdlib_logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.settings import settings
from app.logging.setup import setup_logging
from app.middleware.logging_middleware import RequestLoggingMiddleware
from app.config.github_loader import GitHubConfigLoader
from app.config.registry import init_loader
from app.db.session import engine, dispose_engine
from app.db import models as db_models

logger = logging.getLogger(__name__)


# ── Lifespan ───────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):

    # ── 1. Logging ─────────────────────────────────────────────────────────────
    setup_logging()
    logger.info(
        "Starting placement-engine",
        extra={"env": settings.app_env, "version": settings.app_version},
    )

    # ── 2. GitHub config loader ────────────────────────────────────────────────
    loader = GitHubConfigLoader(
        owner            = settings.github_owner,
        repo             = settings.github_repo,
        path             = settings.github_config_path,
        ref              = settings.github_ref,
        token            = settings.github_token,
        ttl              = settings.config_ttl,
        refresh_interval = settings.config_refresh_interval,
        on_change        = _on_config_change,
    )
    init_loader(loader)
    await loader.start()      # blocks until first fetch succeeds

    # ── 3. DB ──────────────────────────────────────────────────────────────────
    async with engine.begin() as conn:
        await conn.run_sync(db_models.Base.metadata.create_all)
    logger.info("DB tables ready")

    yield

    # ── Shutdown ────────────────────────────────────────────────────────────────
    logger.info("Shutting down placement-engine")
    await loader.stop()
    await dispose_engine()
    stdlib_logging.shutdown()


async def _on_config_change(new_config) -> None:
    """Called by GitHubConfigLoader whenever config changes on GitHub."""
    logger.warning(
        "Placement config updated from GitHub",
        extra={
            "version":     new_config.version,
            "environments": list(new_config.environments.keys()),
        },
    )
    # Add any cache invalidation or notification logic here


# ── App factory ────────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="OpenShift Virtualization — Placement Decision Engine",
        version=settings.app_version,
        docs_url="/docs" if settings.app_env != "production" else None,
        redoc_url=None,
        lifespan=lifespan,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID"],
    )
    app.add_middleware(RequestLoggingMiddleware)

    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error(
            "Unhandled exception",
            extra={"path": request.url.path, "error": str(exc)},
            exc_info=True,
        )
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})

    # ── Routers ────────────────────────────────────────────────────────────────
    from app.api.health    import router as health_router
    from app.api.placement import router as placement_router
    from app.api.config    import router as config_router
    from app.api.inventory import router as inventory_router

    app.include_router(health_router,     prefix="/v1",           tags=["Health"])
    app.include_router(placement_router,  prefix="/v1/placement", tags=["Placement"])
    app.include_router(config_router,     prefix="/v1/config",    tags=["Config"])
    app.include_router(inventory_router,  prefix="/v1/inventory", tags=["Inventory"])

    return app


app = create_app()
