"""
app/api/config.py
──────────────────
Config management endpoints.

GET  /v1/config/current   Show active config (what's currently in memory)
GET  /v1/config/status    Cache metadata (SHA, age, staleness)
POST /v1/config/refresh   Trigger immediate re-fetch from GitHub
                          Secured by GitHub webhook HMAC signature

GitHub webhook setup:
  Repo → Settings → Webhooks → Add webhook
    Payload URL:    https://your-app/v1/config/refresh
    Content type:   application/json
    Secret:         value of GITHUB_WEBHOOK_SECRET env var
    Events:         Push (or just "push to main")
"""

import hashlib
import hmac
import logging

from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks

from app.config.registry import get_placement_config, get_loader
from app.config.schema import PlacementConfig
from app.settings import settings

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/current", summary="Active placement config")
async def get_current_config(
    config: PlacementConfig = Depends(get_placement_config),
):
    """
    Return the currently active placement config (what's in memory).
    Shows environments, workload profiles, scoring weights.
    """
    return config.model_dump()


@router.get("/status", summary="Config cache metadata")
async def get_config_status():
    """
    Return cache metadata — SHA, age, TTL, staleness.
    Use this in health dashboards and alerting.
    """
    return get_loader().cache_info


@router.post("/refresh", summary="Force config reload from GitHub")
async def refresh_config(
    request: Request,
    background_tasks: BackgroundTasks,
):
    """
    Force an immediate config reload from GitHub.

    Two usage modes:

    1. GitHub webhook (automatic):
       Configure GitHub to POST here on every push to main.
       Request must carry a valid X-Hub-Signature-256 header.

    2. Manual / CI pipeline:
       POST with header  X-Manual-Refresh: true
       and  Authorization: Bearer <GITHUB_WEBHOOK_SECRET>
       to bypass HMAC signature check.
    """
    body = await request.body()

    # ── Signature verification ────────────────────────────────────────────────
    manual = request.headers.get("X-Manual-Refresh") == "true"

    if manual:
        # Simple Bearer token check for CI/CD pipelines
        auth = request.headers.get("Authorization", "")
        token = settings.github_webhook_secret or ""
        if not token or auth != f"Bearer {token}":
            raise HTTPException(status_code=401, detail="Invalid authorisation")
    else:
        # GitHub HMAC-SHA256 webhook signature
        _verify_github_signature(
            body=body,
            signature_header=request.headers.get("X-Hub-Signature-256", ""),
            secret=settings.github_webhook_secret,
        )

    # ── Trigger refresh in background — return immediately ────────────────────
    background_tasks.add_task(_do_refresh)

    logger.info(
        "Config refresh triggered",
        extra={"manual": manual, "source_ip": request.client.host},
    )

    return {
        "status":  "refresh queued",
        "current": get_loader().cache_info,
    }


# ── Helpers ────────────────────────────────────────────────────────────────────

async def _do_refresh() -> None:
    try:
        changed = await get_loader().refresh(force=True)
        logger.info("Config refresh complete", extra={"changed": changed})
    except Exception as exc:
        logger.error("Config refresh failed", extra={"error": str(exc)})


def _verify_github_signature(body: bytes, signature_header: str, secret: Optional[str]) -> None:
    """
    Verify GitHub webhook HMAC-SHA256 signature.
    Raises HTTPException(401) on failure.
    """
    if not secret:
        # No secret configured — skip verification (dev mode)
        logger.warning("GITHUB_WEBHOOK_SECRET not set — skipping signature verification")
        return

    if not signature_header.startswith("sha256="):
        raise HTTPException(status_code=401, detail="Missing X-Hub-Signature-256 header")

    expected = "sha256=" + hmac.new(
        key=secret.encode("utf-8"),
        msg=body,
        digestmod=hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected, signature_header):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")


# Fix missing import
from typing import Optional
