"""app/api/health.py — health endpoints including config cache status."""

import logging
from fastapi import APIRouter, Response
from app.db.session import check_db_health
from app.config.registry import get_loader
from app.logging.setup import get_splunk_handler

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/health", summary="Liveness probe")
async def liveness():
    return {"status": "ok"}


@router.get("/health/db", summary="Readiness probe")
async def readiness(response: Response):
    result = await check_db_health()
    if result["status"] != "ok":
        response.status_code = 503
    return result


@router.get("/health/full", summary="Full diagnostics")
async def full_health():
    db     = await check_db_health()
    config = get_loader().cache_info

    # Readiness degraded if config is stale beyond 2× TTL
    config_ok = config.get("loaded") and not config.get("stale", False)

    splunk = None
    handler = get_splunk_handler()
    if handler:
        s = handler.stats
        splunk = {
            "active":          True,
            "queue_depth":     handler.queue_depth,
            "events_shipped":  s.events_shipped,
            "events_dropped":  s.events_dropped,
            "batches_failed":  s.batches_failed,
            "last_error":      s.last_error,
        }
    else:
        splunk = {"active": False}

    overall = (
        "ok"       if db["status"] == "ok" and config_ok
        else "degraded"
    )

    return {
        "status":   overall,
        "database": db,
        "config":   config,
        "splunk":   splunk,
    }
