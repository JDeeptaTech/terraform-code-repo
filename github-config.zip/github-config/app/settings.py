"""
app/settings.py
────────────────
Application settings loaded from environment variables.
These are infra/deployment concerns (not placement business logic).
Placement business logic lives in the GitHub config repo.
"""

from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):

    # ── Application ────────────────────────────────────────────────────────────
    app_env:     str = "development"
    app_version: str = "1.0.0"
    log_level:   str = "INFO"

    # ── Database (inventory: clusters, networks, datastores) ───────────────────
    database_url: str = (
        "postgresql+asyncpg://placement:placement@localhost:5432/placement_engine"
    )

    # ── GitHub config source ───────────────────────────────────────────────────
    github_owner:       str           = "my-org"
    github_repo:        str           = "platform-config"
    github_config_path: str           = "placement/config.yaml"
    github_ref:         str           = "main"       # branch, tag, or commit SHA
    github_token:       Optional[str] = None         # PAT with contents:read
    config_ttl:         int           = 60           # seconds before re-fetch
    config_refresh_interval: int      = 60           # background refresh interval

    # ── GitHub webhook secret (for POST /v1/config/refresh) ───────────────────
    github_webhook_secret: Optional[str] = None

    # ── Splunk ─────────────────────────────────────────────────────────────────
    splunk_hec_url:    Optional[str] = None
    splunk_hec_token:  Optional[str] = None
    splunk_index:      str           = "main"
    splunk_source:     str           = "placement-engine"
    splunk_verify_ssl: bool          = True

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


settings = Settings()
