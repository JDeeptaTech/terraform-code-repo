"""
tests/test_github_config.py
────────────────────────────
Unit tests for GitHub config loader and schema parsing.
No real GitHub API calls — all network I/O is mocked.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from app.config.schema import (
    PlacementConfig,
    parse_config,
    TagRules,
    ScoringWeights,
    _union,
)


SAMPLE_YAML = """
version: "1.0"
scoring:
  weights:
    compute:   0.50
    network:   0.25
    datastore: 0.25
  datastore_target_utilisation: 0.75
  cluster_headroom_target: 0.20
defaults:
  strategy: best_fit
  top_n: 3
  ha_required: true
environments:
  prod:
    cluster_tags:
      must_have: ["prod", "ocp-virt"]
      any_of:    ["region-uksouth", "region-ukwest"]
      exclude:   ["maintenance"]
    cluster_prefer_tags: ["high-memory"]
    network_tags:
      must_have: ["vlan-prod"]
      exclude:   ["deprecated"]
    datastore_tags:
      must_have: ["prod-storage"]
      any_of:    ["nvme", "ssd"]
      exclude:   ["archive"]
    datastore_constraints:
      min_free_gb: 100
      min_free_percent: 15.0
  dev:
    cluster_tags:
      must_have: ["dev", "ocp-virt"]
    network_tags:
      must_have: ["vlan-dev"]
    datastore_tags:
      must_have: ["dev-storage"]
    ha_required: false
    strategy: spread
workload_profiles:
  gpu:
    cluster_tags:
      any_of: ["gpu-enabled"]
    cluster_prefer_tags: ["gpu-a100"]
  memory_intensive:
    cluster_prefer_tags: ["high-memory", "numa-optimised"]
"""


class TestParsing:

    def test_parse_yaml_valid(self):
        config = parse_config(SAMPLE_YAML)
        assert config.version == "1.0"
        assert config.scoring.weights.compute == 0.50
        assert "prod" in config.environments
        assert "dev"  in config.environments
        assert "gpu"  in config.workload_profiles

    def test_weights_must_sum_to_one(self):
        bad_yaml = """
scoring:
  weights:
    compute:   0.60
    network:   0.30
    datastore: 0.20
"""
        with pytest.raises(Exception, match="sum to 1.0"):
            parse_config(bad_yaml)

    def test_invalid_strategy(self):
        bad_yaml = "defaults:\n  strategy: invalid_strategy\n"
        with pytest.raises(Exception):
            parse_config(bad_yaml)

    def test_empty_yaml_uses_defaults(self):
        config = parse_config("{}")
        assert config.defaults.strategy    == "best_fit"
        assert config.defaults.ha_required is True
        assert config.scoring.weights.compute == 0.50

    def test_parse_json(self):
        import json
        data = {
            "version": "1.0",
            "environments": {
                "prod": {
                    "cluster_tags": {"must_have": ["prod"]}
                }
            }
        }
        config = parse_config(json.dumps(data), source_path="config.json")
        assert "prod" in config.environments


class TestMergeSelectors:

    def setup_method(self):
        self.config = parse_config(SAMPLE_YAML)

    def test_prod_balanced_merge(self):
        sel = self.config.merge_selectors("prod", "balanced")
        assert "prod"        in sel.cluster_must_have
        assert "ocp-virt"    in sel.cluster_must_have
        assert "maintenance" in sel.cluster_exclude
        assert "vlan-prod"   in sel.network_must_have
        assert "prod-storage" in sel.datastore_must_have
        assert sel.min_free_gb == 100
        assert sel.min_free_percent == 15.0
        assert sel.ha_required is True
        assert sel.strategy == "best_fit"

    def test_dev_overrides_ha_and_strategy(self):
        sel = self.config.merge_selectors("dev", "balanced")
        assert sel.ha_required is False
        assert sel.strategy == "spread"

    def test_gpu_workload_adds_any_of(self):
        sel = self.config.merge_selectors("prod", "gpu")
        # Workload profile adds any_of for GPU
        assert "gpu-enabled" in sel.cluster_any_of
        # Environment prefer_tags + workload prefer_tags merged
        assert "high-memory" in sel.cluster_prefer
        assert "gpu-a100"    in sel.cluster_prefer

    def test_memory_intensive_adds_prefer_tags(self):
        sel = self.config.merge_selectors("prod", "memory_intensive")
        assert "high-memory"    in sel.cluster_prefer
        assert "numa-optimised" in sel.cluster_prefer

    def test_unknown_environment_returns_empty(self):
        sel = self.config.merge_selectors("nonexistent", "balanced")
        # Falls back to global defaults
        assert sel.cluster_must_have == []
        assert sel.ha_required == self.config.defaults.ha_required
        assert sel.strategy    == self.config.defaults.strategy

    def test_unknown_workload_type_no_error(self):
        sel = self.config.merge_selectors("prod", "unknown_type")
        # Workload profile just adds nothing — env tags still applied
        assert "prod" in sel.cluster_must_have

    def test_exclude_tags_always_union(self):
        """Exclusions from both env and workload must both be present."""
        sel = self.config.merge_selectors("prod", "balanced")
        assert "maintenance" in sel.cluster_exclude
        assert "deprecated"  in sel.network_exclude
        assert "archive"     in sel.datastore_exclude


class TestUnionHelper:

    def test_deduplicates(self):
        result = _union(["a", "b"], ["b", "c"])
        assert result == ["a", "b", "c"]

    def test_preserves_order(self):
        result = _union(["z", "a"], ["m"])
        assert result == ["z", "a", "m"]

    def test_empty_lists(self):
        assert _union([], []) == []
        assert _union(["a"], []) == ["a"]


class TestGitHubLoaderMocked:
    """Test GitHubConfigLoader without real network calls."""

    @pytest.mark.asyncio
    async def test_start_fetches_on_startup(self):
        from app.config.github_loader import GitHubConfigLoader

        loader = GitHubConfigLoader(
            owner="org", repo="repo", path="config.yaml", token="tok"
        )

        with patch.object(loader, "_fetch_from_github", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.return_value = (SAMPLE_YAML, "abc123sha", None)

            # Cancel background task immediately
            with patch.object(loader, "_background_refresh", new_callable=AsyncMock):
                await loader.start()

            config = await loader.get()
            assert config.version == "1.0"
            mock_fetch.assert_called_once()

        await loader._client.aclose()

    @pytest.mark.asyncio
    async def test_no_reload_if_sha_unchanged(self):
        from app.config.github_loader import GitHubConfigLoader

        loader = GitHubConfigLoader(owner="org", repo="repo", path="config.yaml")

        with patch.object(loader, "_fetch_from_github", new_callable=AsyncMock) as mock_fetch:
            mock_fetch.return_value = (SAMPLE_YAML, "same-sha", None)

            with patch.object(loader, "_background_refresh", new_callable=AsyncMock):
                await loader.start()       # first fetch
                changed = await loader.refresh()  # second fetch — same SHA

            assert changed is False
            assert mock_fetch.call_count == 2

        await loader._client.aclose()

    @pytest.mark.asyncio
    async def test_uses_stale_cache_if_github_fails(self):
        from app.config.github_loader import GitHubConfigLoader

        loader = GitHubConfigLoader(owner="org", repo="repo", path="config.yaml")

        call_count = 0

        async def fetch_side_effect():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return (SAMPLE_YAML, "sha1", None)
            raise ConnectionError("GitHub unreachable")

        with patch.object(loader, "_fetch_from_github", side_effect=fetch_side_effect):
            with patch.object(loader, "_background_refresh", new_callable=AsyncMock):
                await loader.start()
                changed = await loader.refresh()   # second call fails

            # Should still return the stale cached config
            config = await loader.get()
            assert config is not None
            assert changed is False

        await loader._client.aclose()
