-- scripts/init.sql
-- Runs once when the PostgreSQL container is first created.

-- Enable pgcrypto for UUID generation (used by placement_log if needed)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Confirm LISTEN/NOTIFY works (placement_config_updated channel used by sync_bus)
-- No setup needed — PostgreSQL NOTIFY requires no DDL.

-- Optional: Create a dedicated role for the sync bus listener connections
-- (same user is fine for local dev, but useful for production RBAC)
-- GRANT CONNECT ON DATABASE placement_engine TO placement;

-- Log that init ran
DO $$
BEGIN
  RAISE NOTICE 'placement_engine DB initialised';
END $$;
