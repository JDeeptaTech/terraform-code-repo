"""
MULTI-WORKER PROBLEM ANALYSIS
══════════════════════════════

With Gunicorn + 5 workers, each worker is a separate OS process (fork).
This breaks three things from the single-worker design:

┌──────────────────────────────────────────────────────────────────────┐
│  PROBLEM 1: In-memory config is NOT shared                           │
│                                                                      │
│  Worker 1 ──► GitHubConfigLoader (its own copy, its own cache)      │
│  Worker 2 ──► GitHubConfigLoader (its own copy, its own cache)      │
│  Worker 3 ──► GitHubConfigLoader (its own copy, its own cache)      │
│  Worker 4 ──► GitHubConfigLoader (its own copy, its own cache)      │
│  Worker 5 ──► GitHubConfigLoader (its own copy, its own cache)      │
│                                                                      │
│  A webhook hitting Worker 1 does NOT update Workers 2-5.            │
│  Workers serve inconsistent config until each one's TTL expires.    │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│  PROBLEM 2: 5× GitHub API background tasks                           │
│                                                                      │
│  5 workers × poll every 60s = 5× API calls                          │
│  5 workers × release watcher poll = 5× release checks               │
│  With a PAT: 5000 req/hr. 5 workers × 60 polls/hr = 300 req/hr.    │
│  Manageable, but wasteful and risks rate limiting under load.        │
└──────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────┐
│  PROBLEM 3: DB connection pool math changes                          │
│                                                                      │
│  Previous:  2 workers × (10 + 10) = 40 connections per pod          │
│  Now:       5 workers × (10 + 10) = 100 connections per pod         │
│  3 pods:    3 × 100 = 300 — EXCEEDS PostgreSQL default max (100)    │
│  Must reduce pool_size or use PgBouncer.                             │
└──────────────────────────────────────────────────────────────────────┘

SOLUTION
════════

Use PostgreSQL LISTEN/NOTIFY for cross-worker synchronisation.
You already have PostgreSQL — no extra infrastructure needed.

Architecture:

  Webhook → Worker 1
               │
               ├── Loads new config from GitHub
               ├── Updates its own in-memory cache
               └── NOTIFY placement_config_updated (channel)
                         │
                         ▼
          ┌──────────────────────────┐
          │   PostgreSQL NOTIFY bus  │
          └──────────────────────────┘
                 │        │       │       │
                 ▼        ▼       ▼       ▼
             Worker2  Worker3  Worker4  Worker5
             (LISTEN)  each receives NOTIFY immediately
             each reloads config from GitHub within ~1s

Each worker still has its own GitHubConfigLoader but they stay
synchronised via PostgreSQL pub/sub instead of fighting over
in-memory state.

DB POOL FIX
═══════════
5 workers → reduce pool per worker:

  pool_size     = 4   (was 10)
  max_overflow  = 4   (was 10)
  per worker    = 8 max connections
  5 workers     = 40 max connections per pod
  3 pods        = 120 total — safely within PostgreSQL 150 limit

  Set DB_POOL_SIZE=4, DB_MAX_OVERFLOW=4 in K8s ConfigMap.
"""
