"""
tests/test_sync_bus.py
───────────────────────
Unit tests for the PostgreSQL LISTEN/NOTIFY sync bus.
All network I/O is mocked — no real DB needed.
"""
import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, call
from app.config.sync_bus import ConfigSyncBus, CHANNEL, _to_asyncpg_dsn


class TestDsnConversion:
    def test_converts_sqlalchemy_url(self):
        url = "postgresql+asyncpg://user:pass@host:5432/db"
        assert _to_asyncpg_dsn(url) == "postgresql://user:pass@host:5432/db"

    def test_plain_url_unchanged(self):
        url = "postgresql://user:pass@host/db"
        assert _to_asyncpg_dsn(url) == url


class TestSyncBus:

    def _bus(self, on_notify=None, worker_id="worker-1"):
        return ConfigSyncBus(
            database_url="postgresql://localhost/test",
            on_notify=on_notify or AsyncMock(),
            worker_id=worker_id,
        )

    @pytest.mark.asyncio
    async def test_start_connects_and_listens(self):
        bus  = self._bus()
        conn = AsyncMock()
        conn.is_closed.return_value = False

        with patch("asyncpg.connect", new_callable=AsyncMock, return_value=conn):
            with patch.object(bus, "_listen_loop", new_callable=AsyncMock):
                await bus.start()

        conn.add_listener.assert_called_once_with(CHANNEL, bus._handle_notification)
        await bus.stop()

    @pytest.mark.asyncio
    async def test_publish_sends_notify(self):
        bus  = self._bus(worker_id="w1")
        conn = AsyncMock()

        with patch("asyncpg.connect", new_callable=AsyncMock, return_value=conn):
            await bus.publish(ref="v1.4.0", sha="abc123", reason="webhook")

        conn.execute.assert_called_once()
        args   = conn.execute.call_args[0]
        assert "pg_notify" in args[0]
        payload = json.loads(args[2])
        assert payload["ref"]         == "v1.4.0"
        assert payload["sha"]         == "abc123"
        assert payload["reason"]      == "webhook"
        assert payload["from_worker"] == "w1"

    @pytest.mark.asyncio
    async def test_handle_notification_calls_on_notify(self):
        callback = AsyncMock()
        bus = self._bus(on_notify=callback, worker_id="w2")

        payload = json.dumps({
            "ref": "v1.4.0", "sha": "abc123",
            "reason": "webhook", "from_worker": "w1",  # different worker
        })

        mock_conn = MagicMock()
        await bus._handle_notification(mock_conn, 1234, CHANNEL, payload)

        callback.assert_called_once()
        data = callback.call_args[0][0]
        assert data["ref"]    == "v1.4.0"
        assert data["reason"] == "webhook"

    @pytest.mark.asyncio
    async def test_self_published_notify_ignored(self):
        """A worker must not react to its own NOTIFY."""
        callback = AsyncMock()
        bus = self._bus(on_notify=callback, worker_id="w1")

        payload = json.dumps({
            "ref": "v1.4.0", "sha": "abc123",
            "reason": "webhook", "from_worker": "w1",  # SAME worker
        })
        await bus._handle_notification(MagicMock(), 1, CHANNEL, payload)
        callback.assert_not_called()

    @pytest.mark.asyncio
    async def test_publish_failure_does_not_raise(self):
        """Publish failures are non-fatal — other workers catch up via TTL."""
        bus = self._bus()
        with patch("asyncpg.connect", side_effect=ConnectionRefusedError("db down")):
            # Should log a warning but NOT raise
            await bus.publish(ref="v1.0.0", sha="abc", reason="test")

    @pytest.mark.asyncio
    async def test_on_notify_exception_does_not_crash_bus(self):
        """Bus stays alive even if the callback raises."""
        async def bad_callback(data):
            raise ValueError("callback exploded")

        bus = self._bus(on_notify=bad_callback, worker_id="w2")
        payload = json.dumps({"ref": "v1.0.0", "from_worker": "w1"})
        # Should not raise
        await bus._handle_notification(MagicMock(), 1, CHANNEL, payload)

    @pytest.mark.asyncio
    async def test_dsn_used_for_listener(self):
        """asyncpg.connect should receive postgresql:// not postgresql+asyncpg://"""
        bus = ConfigSyncBus(
            database_url="postgresql+asyncpg://u:p@host/db",
            on_notify=AsyncMock(),
            worker_id="w1",
        )
        conn = AsyncMock()
        conn.is_closed.return_value = False

        with patch("asyncpg.connect", new_callable=AsyncMock, return_value=conn) as mock_connect:
            with patch.object(bus, "_listen_loop", new_callable=AsyncMock):
                await bus.start()

        dsn_used = mock_connect.call_args[0][0]
        assert dsn_used.startswith("postgresql://")
        assert "asyncpg" not in dsn_used
        await bus.stop()


class TestSyncBusIntegration:
    """
    Integration scenario: worker A publishes, worker B receives and reloads.
    Everything except asyncpg and GitHubConfigLoader.refresh is real code.
    """

    @pytest.mark.asyncio
    async def test_worker_b_reloads_on_notify_from_worker_a(self):
        reload_called = asyncio.Event()

        async def mock_reload(data: dict):
            assert data["ref"]    == "v1.5.0"
            assert data["reason"] == "webhook:release"
            reload_called.set()

        bus_b = ConfigSyncBus(
            database_url="postgresql://localhost/test",
            on_notify=mock_reload,
            worker_id="worker-B",
        )

        # Simulate receiving a NOTIFY directly (bypassing real DB)
        payload = json.dumps({
            "ref": "v1.5.0", "sha": "deadbeef",
            "reason": "webhook:release", "from_worker": "worker-A",
        })
        await bus_b._handle_notification(MagicMock(), 999, CHANNEL, payload)

        assert reload_called.is_set(), "Worker B should have triggered a reload"
