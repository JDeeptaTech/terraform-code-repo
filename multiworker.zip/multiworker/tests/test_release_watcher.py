"""
tests/test_release_watcher.py
──────────────────────────────
Unit tests for release watcher — all GitHub API calls mocked.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch, call
from app.config.release_watcher import (
    ReleaseWatcher,
    ConfigStrategy,
    GitRef,
    PromotionEvent,
    parse_semver,
    satisfies_range,
)


# ── Semver helpers ─────────────────────────────────────────────────────────────

class TestParseSemver:
    def test_plain(self):       assert parse_semver("1.2.3")         == (1, 2, 3)
    def test_v_prefix(self):    assert parse_semver("v1.2.3")        == (1, 2, 3)
    def test_in_string(self):   assert parse_semver("release-1.2.3") == (1, 2, 3)
    def test_none(self):        assert parse_semver("main")           is None
    def test_partial(self):     assert parse_semver("1.2")            is None


class TestSatisfiesRange:
    def test_gte(self):         assert satisfies_range((1,3,0), ">=1.0.0") is True
    def test_gte_fail(self):    assert satisfies_range((0,9,0), ">=1.0.0") is False
    def test_lt(self):          assert satisfies_range((1,9,0), "<2.0.0")  is True
    def test_lt_fail(self):     assert satisfies_range((2,0,0), "<2.0.0")  is False
    def test_combined(self):    assert satisfies_range((1,5,0), ">=1.0.0 <2.0.0") is True
    def test_combined_fail(self): assert satisfies_range((2,0,0), ">=1.0.0 <2.0.0") is False
    def test_caret(self):       assert satisfies_range((1,5,0), "^1.0.0") is True
    def test_caret_major(self): assert satisfies_range((2,0,0), "^1.0.0") is False
    def test_tilde(self):       assert satisfies_range((1,2,3), "~1.2.0") is True
    def test_tilde_fail(self):  assert satisfies_range((1,3,0), "~1.2.0") is False
    def test_empty(self):       assert satisfies_range((9,9,9), "")        is True


# ── Watcher ────────────────────────────────────────────────────────────────────

def _make_ref(name: str, ref_type="release") -> GitRef:
    return GitRef(
        name=name,
        ref_type=ref_type,
        sha=f"sha-{name}",
        semver=parse_semver(name),
    )


class TestReleaseWatcher:

    def _watcher(self, strategy=ConfigStrategy.LATEST_RELEASE, **kwargs) -> ReleaseWatcher:
        return ReleaseWatcher(
            owner="org", repo="repo",
            strategy=strategy,
            poll_interval=0,    # no background polling in tests
            token="tok",
            **kwargs,
        )

    @pytest.mark.asyncio
    async def test_start_latest_release(self):
        w = self._watcher()
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "tag_name": "v1.3.0", "prerelease": False, "published_at": "2024-01-01T00:00:00Z"
        }

        with patch.object(w._client, "get", new_callable=AsyncMock) as mock_get:
            # First call: /releases/latest    Second: /git/ref/tags/v1.3.0
            sha_resp = MagicMock(status_code=200)
            sha_resp.json.return_value = {"object": {"sha": "abc123", "type": "commit"}}
            mock_get.side_effect = [mock_resp, sha_resp]

            with patch.object(w, "_poll_loop", new_callable=AsyncMock):
                ref = await w.start()

        assert ref.name == "v1.3.0"
        assert ref.semver == (1, 3, 0)
        assert ref.prerelease is False
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_semver_range_selects_highest(self):
        w = self._watcher(
            strategy=ConfigStrategy.SEMVER_RANGE,
            semver_range=">=1.0.0 <2.0.0"
        )
        tags_resp = MagicMock(status_code=200)
        tags_resp.json.return_value = [
            {"name": "v0.9.0", "commit": {"sha": "sha1"}},
            {"name": "v1.2.0", "commit": {"sha": "sha2"}},
            {"name": "v1.5.0", "commit": {"sha": "sha3"}},   # ← should win
            {"name": "v2.0.0", "commit": {"sha": "sha4"}},   # excluded by range
            {"name": "not-a-version", "commit": {"sha": "sha5"}},
        ]
        with patch.object(w._client, "get", new_callable=AsyncMock, return_value=tags_resp):
            with patch.object(w, "_poll_loop", new_callable=AsyncMock):
                ref = await w.start()

        assert ref.name    == "v1.5.0"
        assert ref.semver  == (1, 5, 0)
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_is_better_higher_semver(self):
        w = self._watcher()
        w._active_ref = _make_ref("v1.2.0")

        candidate = _make_ref("v1.3.0")
        assert w._is_better(candidate) is True

    @pytest.mark.asyncio
    async def test_is_better_lower_semver_rejected(self):
        w = self._watcher()
        w._active_ref = _make_ref("v1.5.0")

        candidate = _make_ref("v1.3.0")
        assert w._is_better(candidate) is False

    @pytest.mark.asyncio
    async def test_is_better_same_sha_rejected(self):
        w = self._watcher()
        w._active_ref = GitRef(name="v1.0.0", ref_type="release", sha="same-sha", semver=(1,0,0))
        candidate     = GitRef(name="v1.0.1", ref_type="release", sha="same-sha", semver=(1,0,1))

        assert w._is_better(candidate) is False   # same SHA = no actual change

    @pytest.mark.asyncio
    async def test_is_better_pinned_always_false(self):
        w = self._watcher(strategy=ConfigStrategy.PINNED)
        w._active_ref = _make_ref("v1.0.0")
        assert w._is_better(_make_ref("v9.9.9")) is False

    @pytest.mark.asyncio
    async def test_on_promote_callback_called(self):
        callback = AsyncMock()
        w = self._watcher(on_promote=callback)
        w._active_ref = _make_ref("v1.0.0")
        new_ref       = _make_ref("v1.1.0")

        event = await w._promote(new_ref, reason="test")

        callback.assert_called_once()
        ev = callback.call_args[0][0]
        assert isinstance(ev, PromotionEvent)
        assert ev.current.name == "v1.1.0"
        assert ev.previous.name == "v1.0.0"
        assert ev.reason == "test"
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_webhook_release_published_triggers_check(self):
        w = self._watcher()
        w._active_ref = _make_ref("v1.0.0")

        new_ref = _make_ref("v1.1.0")
        with patch.object(w, "_discover_best_ref", new_callable=AsyncMock, return_value=new_ref):
            event = await w.handle_webhook_event(
                "release",
                {"action": "published", "release": {"tag_name": "v1.1.0"}},
                reason="webhook",
            )

        assert event is not None
        assert event.current.name == "v1.1.0"
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_webhook_release_other_action_ignored(self):
        w = self._watcher()
        w._active_ref = _make_ref("v1.0.0")

        event = await w.handle_webhook_event("release", {"action": "deleted"})
        assert event is None
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_webhook_tag_created_triggers_check(self):
        w = self._watcher()
        w._active_ref = _make_ref("v1.0.0")

        new_ref = _make_ref("v1.2.0")
        with patch.object(w, "_discover_best_ref", new_callable=AsyncMock, return_value=new_ref):
            event = await w.handle_webhook_event(
                "create",
                {"ref_type": "tag", "ref": "v1.2.0"},
                reason="webhook:create",
            )

        assert event is not None
        assert event.current.name == "v1.2.0"
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_webhook_push_only_for_track_branch(self):
        w = self._watcher(strategy=ConfigStrategy.LATEST_RELEASE)
        w._active_ref = _make_ref("v1.0.0")

        # push event should be ignored for latest_release strategy
        event = await w.handle_webhook_event("push", {"ref": "refs/heads/main"})
        assert event is None
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_prerelease_skipped_when_not_allowed(self):
        w = self._watcher(allow_prerelease=False)

        latest_resp = MagicMock(status_code=200)
        latest_resp.json.return_value = {"tag_name": "v2.0.0-rc1", "prerelease": True}

        stable_list = MagicMock(status_code=200)
        stable_list.json.return_value = [
            {"tag_name": "v1.5.0", "prerelease": False, "published_at": "2024-01-01"},
        ]

        sha_resp = MagicMock(status_code=200)
        sha_resp.json.return_value = {"object": {"sha": "abc", "type": "commit"}}

        with patch.object(w._client, "get", new_callable=AsyncMock,
                          side_effect=[latest_resp, stable_list, sha_resp]):
            with patch.object(w, "_poll_loop", new_callable=AsyncMock):
                ref = await w.start()

        assert ref.name == "v1.5.0"
        assert ref.prerelease is False
        await w._client.aclose()

    @pytest.mark.asyncio
    async def test_promote_to_manual_ref(self):
        w = self._watcher()
        w._active_ref = _make_ref("v1.0.0")

        sha_resp = MagicMock(status_code=200)
        sha_resp.json.return_value = {"object": {"sha": "manual-sha", "type": "commit"}}

        with patch.object(w._client, "get", new_callable=AsyncMock, return_value=sha_resp):
            event = await w.promote_to("v0.9.0", reason="rollback-test")

        assert event.current.name == "v0.9.0"
        assert event.reason == "rollback-test"
        assert w.active_ref.name == "v0.9.0"
        await w._client.aclose()
