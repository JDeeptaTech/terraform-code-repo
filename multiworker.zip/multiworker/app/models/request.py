"""
app/models/request.py
──────────────────────
Placement request model.

Key change from DB-backed version:
  Tag selectors are NO LONGER in the request body.
  They are resolved server-side from:
    environment   (maps to environments.<env> in GitHub config)
    workload_type (maps to workload_profiles.<type> in GitHub config)

This simplifies caller payloads massively — clients only specify
what they want to run, not how to find it.
"""

from pydantic import BaseModel, Field
from typing import Optional, Literal


class WorkloadProfile(BaseModel):
    name:          str   = Field(..., examples=["finance-db-vm"])
    cpu_cores:     int   = Field(..., ge=1,  examples=[8])
    memory_gb:     float = Field(..., gt=0,  examples=[64.0])
    disk_gb:       float = Field(..., gt=0,  examples=[500.0])
    workload_type: Literal[
        "compute_intensive",
        "memory_intensive",
        "balanced",
        "gpu",
    ] = "balanced"
    namespace:     Optional[str] = Field(default=None, examples=["finance-prod"])


class PlacementRequest(BaseModel):
    workload:     WorkloadProfile
    environment:  str  = Field(
        ...,
        description="Maps to environments.<env> in GitHub config (e.g. 'prod', 'dev')",
        examples=["prod"],
    )
    strategy:     Optional[Literal["best_fit", "spread", "packed"]] = Field(
        default=None,
        description="Override strategy from GitHub config. If null, uses config default.",
    )
    top_n:        int  = Field(default=3, ge=1, le=10)
    dry_run:      bool = Field(default=False)
