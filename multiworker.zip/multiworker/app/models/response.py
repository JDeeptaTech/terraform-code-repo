"""app/models/response.py"""
from __future__ import annotations
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel


class ResourceScore(BaseModel):
    compute:   float
    network:   float
    datastore: float
    total:     float


class ClusterCandidate(BaseModel):
    cluster_name:             str
    cluster_id:               int
    score:                    ResourceScore
    available_cpu:            float
    available_memory_gb:      float
    total_cpu:                float
    total_memory_gb:          float
    recommended_network:      str
    recommended_datastore:    str
    recommended_node:         Optional[str]
    cluster_preference_hits:  int = 0
    network_preference_hits:  int = 0
    datastore_preference_hits: int = 0
    reason:                   str


class PlacementDecision(BaseModel):
    request_id:         str
    workload_name:      str
    strategy:           str
    environment:        str
    config_sha:         str
    feasible:           bool
    dry_run:            bool
    recommended:        Optional[ClusterCandidate]
    alternatives:       List[ClusterCandidate] = []
    warnings:           List[str] = []
    evaluated_clusters: int
    rejected_clusters:  int
    created_at:         datetime
