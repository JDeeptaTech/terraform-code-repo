"""
app/api/placement.py
─────────────────────
Placement decision endpoints — now config driven from GitHub.

Notice the request body is simpler:
  - No tag selectors (those live in GitHub config)
  - Just workload spec + environment name + optional strategy override
"""

import logging
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.config.registry import get_placement_config
from app.config.schema import PlacementConfig
from app.models.request import PlacementRequest
from app.models.response import PlacementDecision
from app.engine.decision import run_placement

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post("/decide", response_model=PlacementDecision, summary="Run placement decision")
async def decide_placement(
    request:  PlacementRequest,
    config:   PlacementConfig      = Depends(get_placement_config),
    db:       AsyncSession         = Depends(get_db),
):
    """
    Runs the placement decision engine.

    Tag selectors, scoring weights, and environment constraints are
    resolved from the GitHub config repo — not from the request body.

    Set `dry_run: true` to evaluate feasibility only.
    """
    return await run_placement(request, config, db)


@router.post("/validate", summary="Validate feasibility (dry run)")
async def validate_placement(
    request:  PlacementRequest,
    config:   PlacementConfig = Depends(get_placement_config),
    db:       AsyncSession    = Depends(get_db),
):
    """Quick feasibility check without recording the decision."""
    request.dry_run = True
    decision = await run_placement(request, config, db)
    return {
        "feasible":           decision.feasible,
        "warnings":           decision.warnings,
        "top_score":          decision.recommended.score.total if decision.recommended else None,
        "evaluated_clusters": decision.evaluated_clusters,
        "rejected_clusters":  decision.rejected_clusters,
        "config_sha":         decision.config_sha,
    }
