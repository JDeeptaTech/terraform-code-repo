"""
app/api/config.py
──────────────────
Config management and auto-discovery endpoints.

  GET  /v1/config/current        Active config content
  GET  /v1/config/status         Loader + watcher status, promotion history
  GET  /v1/config/releases       Available releases/tags from GitHub
  POST /v1/config/refresh        Force reload (webhook or manual)
  POST /v1/config/promote        Manually pin to a specific tag/ref
  POST /v1/config/rollback       Roll back to previous ref

GitHub webhook events handled:
  release  (action: published)   → ReleaseWatcher.handle_webhook_event()
  create   (ref_type: tag)       → ReleaseWatcher.handle_webhook_event()
  push     (track_branch only)   → loader.refresh()
"""

import hashlib
import hmac
import logging
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request
from pydantic import BaseModel

from app.config.registry import get_loader, get_watcher, get_placement_config
from app.config.schema import PlacementConfig
from app.settings import settings

router = APIRouter()
logger = logging.getLogger(__name__)


# ── GET /current ───────────────────────────────────────────────────────────────

@router.get("/current", summary="Active placement config")
async def get_current_config(config: PlacementConfig = Depends(get_placement_config)):
    """Returns the currently active config (in-memory, from GitHub)."""
    return config.model_dump()


# ── GET /status ────────────────────────────────────────────────────────────────

@router.get("/status", summary="Loader + watcher status")
async def get_config_status():
    """
    Returns:
      - loader cache info (ref, SHA, age, staleness)
      - watcher status   (strategy, active ref, semver, poll interval)
      - promotion history (last 10 ref changes)
    """
    loader  = get_loader()
    watcher = get_watcher()

    history = [
        {
            "previous_ref": p.previous_ref,
            "current_ref":  p.current_ref,
            "sha":          p.sha,
            "reason":       p.reason,
            "timestamp":    p.timestamp,
        }
        for p in loader.promotion_history[-10:]
    ]

    return {
        "loader":            loader.cache_info,
        "watcher":           watcher.status if watcher else {"active": False},
        "promotion_history": history,
    }


# ── GET /releases ──────────────────────────────────────────────────────────────

@router.get("/releases", summary="Available releases and tags")
async def list_releases():
    """
    Returns the list of refs (releases/tags) the watcher knows about.
    Only available when strategy is latest_release or semver_range.
    """
    watcher = get_watcher()
    if not watcher:
        raise HTTPException(
            status_code=404,
            detail="Release watcher not active (strategy is track_branch or pinned)"
        )
    return {
        "active_ref":  watcher.status["active_ref"],
        "known_refs":  watcher.status["known_refs"],
        "strategy":    watcher.status["strategy"],
        "semver_range": watcher.status["semver_range"],
    }


# ── POST /refresh ──────────────────────────────────────────────────────────────

@router.post("/refresh", summary="GitHub webhook receiver + manual refresh")
async def refresh_config(request: Request, background_tasks: BackgroundTasks):
    """
    Handles GitHub webhook events and manual refresh triggers.

    GitHub webhook events processed:
      X-GitHub-Event: release  (action=published) → checks for promotion
      X-GitHub-Event: create   (ref_type=tag)     → checks for promotion
      X-GitHub-Event: push                        → reloads (track_branch only)
      X-GitHub-Event: ping                        → 200 OK (webhook setup confirmation)

    Manual trigger:
      Header: X-Manual-Refresh: true
      Header: Authorization: Bearer <GITHUB_WEBHOOK_SECRET>
    """
    body = await request.body()

    event_type = request.headers.get("X-GitHub-Event", "")
    manual     = request.headers.get("X-Manual-Refresh") == "true"

    # ── Authorisation ─────────────────────────────────────────────────────────
    if manual:
        _verify_bearer(request.headers.get("Authorization", ""))
    elif event_type:
        _verify_github_signature(body, request.headers.get("X-Hub-Signature-256", ""))
    else:
        raise HTTPException(status_code=400, detail="Missing X-GitHub-Event or X-Manual-Refresh header")

    # ── Ping (webhook registration confirmation) ───────────────────────────────
    if event_type == "ping":
        logger.info("GitHub webhook ping received — webhook registered successfully")
        return {"status": "pong", "message": "Webhook registered"}

    payload = {}
    if body:
        import json
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            pass

    reason = "manual" if manual else f"webhook:{event_type}"
    background_tasks.add_task(_handle_event, event_type, payload, reason)

    logger.info("Config event queued", extra={"event": event_type, "reason": reason})
    return {
        "status":  "queued",
        "event":   event_type or "manual",
        "current": get_loader().cache_info,
    }


# ── POST /promote ──────────────────────────────────────────────────────────────

class PromoteRequest(BaseModel):
    ref:    str
    reason: Optional[str] = "manual-promote"


@router.post("/promote", summary="Manually promote to a specific tag/ref")
async def promote_to_ref(body: PromoteRequest):
    """
    Pin the config to a specific tag, branch, or commit SHA.

    Examples:
      { "ref": "v1.3.0" }          promote to tag v1.3.0
      { "ref": "main" }            switch to branch main
      { "ref": "abc123def456" }    pin to specific commit

    Note: if strategy is latest_release or semver_range, the watcher
    may auto-promote away from this ref on the next poll unless you
    change the strategy to "pinned".
    """
    watcher = get_watcher()
    loader  = get_loader()

    if watcher:
        event = await watcher.promote_to(body.ref, reason=body.reason)
    else:
        # No watcher — directly set ref on loader
        await loader.set_ref(body.ref, reason=body.reason)
        event = None

    return {
        "status":    "promoted",
        "ref":       body.ref,
        "event":     str(event) if event else None,
        "cache_info": loader.cache_info,
    }


# ── POST /rollback ─────────────────────────────────────────────────────────────

@router.post("/rollback", summary="Roll back to previous ref")
async def rollback():
    """
    Roll back to the ref that was active before the most recent promotion.
    Useful for quickly reverting a bad config push.
    """
    loader   = get_loader()
    history  = loader.promotion_history

    if len(history) < 1:
        raise HTTPException(status_code=400, detail="No promotion history — nothing to roll back to")

    last = history[-1]
    if not last.previous_ref:
        raise HTTPException(status_code=400, detail="No previous ref recorded in last promotion")

    prev_ref = last.previous_ref
    logger.warning("Rolling back config", extra={"to_ref": prev_ref, "from_ref": last.current_ref})

    watcher = get_watcher()
    if watcher:
        await watcher.promote_to(prev_ref, reason="rollback")
    else:
        await loader.set_ref(prev_ref, reason="rollback")

    return {
        "status":    "rolled_back",
        "to_ref":    prev_ref,
        "from_ref":  last.current_ref,
        "cache_info": loader.cache_info,
    }


# ── Background event handler ───────────────────────────────────────────────────

async def _handle_event(event_type: str, payload: dict, reason: str) -> None:
    """
    Process a GitHub event in the background.
    Dispatches to watcher (for release/tag events) or loader (for push events).
    """
    try:
        watcher = get_watcher()
        loader  = get_loader()

        if watcher and event_type in ("release", "create"):
            event = await watcher.handle_webhook_event(event_type, payload, reason)
            if event:
                logger.info("Webhook promotion: %s → %s", event.previous, event.current)
            else:
                logger.debug("Webhook event: no promotion triggered (event=%s)", event_type)

        elif event_type == "push":
            changed = await loader.refresh(force=True)
            logger.info("Push refresh: changed=%s ref=%s", changed, loader.active_ref)

        elif event_type in ("release", "create") and not watcher:
            # No watcher but got a tag/release event — do a plain refresh
            changed = await loader.refresh(force=True)
            logger.info("No watcher: plain refresh on %s event, changed=%s", event_type, changed)

    except Exception as exc:
        logger.error("Event handler error (event=%s): %s", event_type, exc, exc_info=True)


# ── Auth helpers ───────────────────────────────────────────────────────────────

def _verify_github_signature(body: bytes, signature_header: str) -> None:
    secret = settings.github_webhook_secret
    if not secret:
        logger.warning("GITHUB_WEBHOOK_SECRET not set — skipping signature check")
        return
    if not signature_header.startswith("sha256="):
        raise HTTPException(status_code=401, detail="Missing X-Hub-Signature-256")
    expected = "sha256=" + hmac.new(
        key=secret.encode(), msg=body, digestmod=hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(expected, signature_header):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")


def _verify_bearer(auth_header: str) -> None:
    secret = settings.github_webhook_secret or ""
    if not secret or auth_header != f"Bearer {secret}":
        raise HTTPException(status_code=401, detail="Invalid authorisation")
