"""app/api/health.py — health checks including per-worker sync bus status."""
import logging
import os
from fastapi import APIRouter, Response
from app.db.session import check_db_health
from app.config.registry import get_loader, get_watcher, get_sync_bus

router   = APIRouter()
logger   = logging.getLogger(__name__)
WORKER   = str(os.getpid())


@router.get("/health", summary="Liveness probe")
async def liveness():
    return {"status": "ok", "worker": WORKER}


@router.get("/health/db", summary="Readiness probe")
async def readiness(response: Response):
    result = await check_db_health()
    if result["status"] != "ok":
        response.status_code = 503
    return result


@router.get("/health/full", summary="Full diagnostics")
async def full_health():
    db      = await check_db_health()
    loader  = get_loader()
    watcher = get_watcher()
    bus     = get_sync_bus()

    cache     = loader.cache_info
    config_ok = cache.get("loaded") and not cache.get("stale", False)

    sync_bus_status = None
    if bus:
        sync_bus_status = {
            "active":    True,
            "worker_id": bus._worker_id,
            "channel":   "placement_config_updated",
            "connected": bus._conn is not None and not bus._conn.is_closed(),
        }

    return {
        "status":  "ok" if db["status"] == "ok" and config_ok else "degraded",
        "worker":  WORKER,
        "database": db,
        "config": {
            "loader":  cache,
            "watcher": watcher.status if watcher else {"active": False},
        },
        "sync_bus": sync_bus_status,
    }
