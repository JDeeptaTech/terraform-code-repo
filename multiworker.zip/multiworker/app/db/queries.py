"""app/db/queries.py"""
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.models import Cluster, Network, Datastore


async def get_all_clusters(db: AsyncSession):
    result = await db.execute(select(Cluster))
    return result.scalars().all()


async def get_all_networks(db: AsyncSession):
    result = await db.execute(select(Network))
    return result.scalars().all()


async def get_all_datastores(db: AsyncSession):
    result = await db.execute(select(Datastore))
    return result.scalars().all()
