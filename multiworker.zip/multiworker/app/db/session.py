"""app/db/session.py — async SQLAlchemy engine, pool sized for 5 workers."""

from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from app.settings import settings

engine = create_async_engine(
    settings.database_url,
    pool_size      = settings.db_pool_size,       # 4 per worker (down from 10)
    max_overflow   = settings.db_max_overflow,     # 4 per worker (down from 10)
    pool_timeout   = settings.db_pool_timeout,
    pool_recycle   = settings.db_pool_recycle,
    pool_pre_ping  = settings.db_pool_pre_ping,
    echo           = settings.db_echo,
    connect_args   = {
        "server_settings": {
            "statement_timeout": "30000",
            "lock_timeout":      "10000",
        }
    },
)

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)


async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def check_db_health() -> dict:
    try:
        async with AsyncSessionLocal() as s:
            await s.execute(__import__("sqlalchemy").text("SELECT 1"))
        pool = engine.pool
        return {
            "status":      "ok",
            "pool_size":   pool.size(),
            "checked_out": pool.checkedout(),
            "overflow":    pool.overflow(),
            "invalid":     pool.invalidated if hasattr(pool, "invalidated") else 0,
        }
    except Exception as exc:
        return {"status": "error", "detail": str(exc)}


async def dispose_engine():
    await engine.dispose()
