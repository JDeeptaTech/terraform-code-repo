"""app/db/models.py"""
from datetime import datetime, timezone
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String, Text, JSON
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


class Cluster(Base):
    __tablename__ = "clusters"
    id                  = Column(Integer, primary_key=True)
    name                = Column(String(120), unique=True, nullable=False)
    tags                = Column(Text, default="")
    total_cpu           = Column(Float, nullable=False)
    available_cpu       = Column(Float, nullable=False)
    total_memory_gb     = Column(Float, nullable=False)
    available_memory_gb = Column(Float, nullable=False)
    ha_enabled          = Column(Boolean, default=False)
    gpu_count           = Column(Integer, default=0)
    least_loaded_node   = Column(String(120), nullable=True)
    updated_at          = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Network(Base):
    __tablename__ = "networks"
    id                   = Column(Integer, primary_key=True)
    name                 = Column(String(120), unique=True, nullable=False)
    tags                 = Column(Text, default="")
    available_on_clusters = Column(Text, default="")
    speed_gbps           = Column(Float, default=1.0)


class Datastore(Base):
    __tablename__ = "datastores"
    id                   = Column(Integer, primary_key=True)
    name                 = Column(String(120), unique=True, nullable=False)
    tags                 = Column(Text, default="")
    available_on_clusters = Column(Text, default="")
    total_gb             = Column(Float, nullable=False)
    used_gb              = Column(Float, nullable=False)
    free_gb              = Column(Float, nullable=False)


class PlacementLog(Base):
    __tablename__ = "placement_log"
    id                    = Column(Integer, primary_key=True)
    workload_name         = Column(String(200))
    environment           = Column(String(80))
    strategy              = Column(String(40))
    config_ref            = Column(String(120))
    config_sha            = Column(String(12))
    dry_run               = Column(Boolean, default=False)
    feasible              = Column(Boolean)
    request_payload       = Column(JSON)
    decision_payload      = Column(JSON)
    recommended_cluster   = Column(String(120), nullable=True)
    total_score           = Column(Float, nullable=True)
    warnings              = Column(JSON)
    created_at            = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
