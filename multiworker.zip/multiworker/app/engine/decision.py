"""
app/engine/decision.py
───────────────────────
Placement decision engine — now driven by GitHub config.

Flow:
  1. Resolve merged selectors from GitHub config
     (environment tags + workload_type overrides)
  2. Load inventory from DB (clusters, networks, datastores)
  3. Filter + score using resolved selectors
  4. Return ranked candidates
"""

import logging
import uuid
from datetime import datetime, timezone
from typing import List

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.schema import PlacementConfig, MergedSelectors
from app.models.request import PlacementRequest
from app.models.response import PlacementDecision, ClusterCandidate, ResourceScore
from app.db.queries import get_all_clusters, get_all_networks, get_all_datastores
from app.engine.tag_matcher import parse_tags, match_tags, parse_cluster_list
from app.db.models import Cluster, Network, Datastore

logger = logging.getLogger(__name__)


async def run_placement(
    request: PlacementRequest,
    config: PlacementConfig,
    db: AsyncSession,
) -> PlacementDecision:
    """
    Run the placement decision pipeline.

    Parameters
    ----------
    request   Inbound placement request (workload spec + environment)
    config    Current PlacementConfig loaded from GitHub
    db        Async DB session for inventory queries
    """
    workload = request.workload
    warnings: List[str] = []
    request_id = str(uuid.uuid4())

    # ── Step 1: Resolve selectors from GitHub config ───────────────────────────
    selectors = config.merge_selectors(
        env=request.environment,
        workload_type=workload.workload_type,
    )

    # Request-level strategy override (or fall back to config default)
    strategy = request.strategy or selectors.strategy

    logger.info(
        "Placement started",
        extra={
            "request_id":    request_id,
            "workload":      workload.name,
            "environment":   request.environment,
            "workload_type": workload.workload_type,
            "strategy":      strategy,
        },
    )

    # ── Step 2: Load inventory from DB ─────────────────────────────────────────
    clusters   = await get_all_clusters(db)
    networks   = await get_all_networks(db)
    datastores = await get_all_datastores(db)

    if not clusters:
        return _infeasible(request_id, workload.name, strategy, request.dry_run,
                           ["No clusters found in inventory"])

    # ── Step 3: Filter clusters ────────────────────────────────────────────────
    from app.services.cluster_selector import select_clusters_with_selectors
    from app.services.network_selector import pick_best_network_with_selectors
    from app.services.datastore_selector import pick_best_datastore_with_selectors

    scored_clusters, rejected_clusters = select_clusters_with_selectors(
        clusters=clusters,
        selectors=selectors,
        workload=workload,
        strategy=strategy,
        scoring_config=config.scoring,
    )

    logger.info(
        "Cluster selection",
        extra={
            "request_id": request_id,
            "passed":     len(scored_clusters),
            "rejected":   len(rejected_clusters),
        },
    )

    if not scored_clusters:
        reasons = "; ".join(
            f"{r.cluster_name}: {r.reason}" for r in rejected_clusters[:3]
        )
        return _infeasible(
            request_id, workload.name, strategy, request.dry_run,
            [f"No clusters passed filters. Sample rejections: {reasons}"],
        )

    # ── Step 4: Per-cluster network + datastore ────────────────────────────────
    candidates: List[ClusterCandidate] = []

    for sc in scored_clusters:
        cluster = sc.cluster

        best_net = pick_best_network_with_selectors(networks, cluster.name, selectors)
        if best_net is None:
            warnings.append(f"Cluster '{cluster.name}' skipped — no network matched")
            continue

        best_ds = pick_best_datastore_with_selectors(
            datastores, cluster.name, selectors, workload.disk_gb, config.scoring
        )
        if best_ds is None:
            warnings.append(f"Cluster '{cluster.name}' skipped — no datastore matched")
            continue

        weights = config.scoring.weights
        total = round(
            sc.total_score  * weights.compute  +
            best_net.score  * weights.network  +
            best_ds.score   * weights.datastore,
            2,
        )

        candidates.append(ClusterCandidate(
            cluster_name=cluster.name,
            cluster_id=cluster.id,
            score=ResourceScore(
                compute=sc.total_score,
                network=best_net.score,
                datastore=best_ds.score,
                total=total,
            ),
            available_cpu=cluster.available_cpu,
            available_memory_gb=cluster.available_memory_gb,
            total_cpu=cluster.total_cpu,
            total_memory_gb=cluster.total_memory_gb,
            recommended_network=best_net.network.name,
            recommended_datastore=best_ds.datastore.name,
            recommended_node=cluster.least_loaded_node,
            cluster_preference_hits=sc.tag_result.preference_hits,
            network_preference_hits=best_net.tag_result.preference_hits,
            datastore_preference_hits=best_ds.tag_result.preference_hits,
            reason=(
                f"Env='{request.environment}' workload='{workload.workload_type}'. "
                f"Cluster pref hits: {sc.tag_result.preference_hits}. "
                f"Net: {best_net.reason}. DS: {best_ds.reason}."
            ),
        ))

    if not candidates:
        return _infeasible(
            request_id, workload.name, strategy, request.dry_run,
            warnings + ["All clusters eliminated at network/datastore stage"],
        )

    candidates.sort(key=lambda c: c.score.total, reverse=True)
    top = candidates[:request.top_n]

    return PlacementDecision(
        request_id=request_id,
        workload_name=workload.name,
        strategy=strategy,
        environment=request.environment,
        config_sha=_get_config_sha(config),
        feasible=True,
        dry_run=request.dry_run,
        recommended=top[0],
        alternatives=top[1:],
        warnings=warnings,
        evaluated_clusters=len(clusters),
        rejected_clusters=len(rejected_clusters) + (len(scored_clusters) - len(candidates)),
        created_at=datetime.now(timezone.utc),
    )


def _infeasible(
    request_id: str,
    workload_name: str,
    strategy: str,
    dry_run: bool,
    warnings: List[str],
) -> PlacementDecision:
    return PlacementDecision(
        request_id=request_id,
        workload_name=workload_name,
        strategy=strategy,
        environment="",
        config_sha="",
        feasible=False,
        dry_run=dry_run,
        recommended=None,
        alternatives=[],
        warnings=warnings,
        evaluated_clusters=0,
        rejected_clusters=0,
        created_at=datetime.now(timezone.utc),
    )


def _get_config_sha(config: PlacementConfig) -> str:
    """Embed config version in response for traceability."""
    try:
        from app.config.registry import get_loader
        return get_loader().cache_info.get("sha", "unknown")
    except Exception:
        return "unknown"
