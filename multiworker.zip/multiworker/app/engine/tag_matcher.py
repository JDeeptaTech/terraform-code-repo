"""app/engine/tag_matcher.py — tag matching helpers."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Set
from app.config.schema import TagRules


@dataclass
class TagMatchResult:
    passed:          bool
    reason:          str = ""
    preference_hits: int = 0


def parse_tags(raw: str) -> Set[str]:
    return {t.strip() for t in raw.split(",") if t.strip()}


def parse_cluster_list(raw: str) -> Set[str]:
    return {c.strip() for c in raw.split(",") if c.strip()}


def match_tags(
    resource_tags: Set[str],
    selector: TagRules,
    prefer_tags: List[str] = None,
) -> TagMatchResult:
    prefer_tags = prefer_tags or []

    for tag in selector.exclude:
        if tag in resource_tags:
            return TagMatchResult(passed=False, reason=f"excluded tag '{tag}'")

    for tag in selector.must_have:
        if tag not in resource_tags:
            return TagMatchResult(passed=False, reason=f"missing required tag '{tag}'")

    if selector.any_of:
        if not any(t in resource_tags for t in selector.any_of):
            return TagMatchResult(passed=False, reason=f"none of any_of tags found")

    hits = sum(1 for t in prefer_tags if t in resource_tags)
    return TagMatchResult(passed=True, preference_hits=hits)
