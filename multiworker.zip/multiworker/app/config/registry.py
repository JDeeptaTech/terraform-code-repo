"""
app/config/registry.py
───────────────────────
Singleton registry — holds loader, watcher, and sync bus.
Each worker process has its own copy of these (they are not shared across forks).
Cross-worker sync is handled by ConfigSyncBus (PostgreSQL NOTIFY).
"""

import logging
from typing import Optional

from app.config.github_loader import GitHubConfigLoader
from app.config.sync_bus import ConfigSyncBus
from app.config.schema import PlacementConfig

logger = logging.getLogger(__name__)

_loader:   Optional[GitHubConfigLoader] = None
_sync_bus: Optional[ConfigSyncBus]      = None

# ReleaseWatcher is optional — imported lazily to avoid circular imports
_watcher = None


def init(
    loader:   GitHubConfigLoader,
    sync_bus: Optional[ConfigSyncBus] = None,
    watcher   = None,
) -> None:
    global _loader, _sync_bus, _watcher
    _loader   = loader
    _sync_bus = sync_bus
    _watcher  = watcher

    # Wire sync bus into loader so set_ref() can publish NOTIFYs
    if sync_bus:
        loader._sync_bus = sync_bus


def get_loader() -> GitHubConfigLoader:
    if not _loader:
        raise RuntimeError("GitHubConfigLoader not initialised")
    return _loader


def get_sync_bus() -> Optional[ConfigSyncBus]:
    return _sync_bus


def get_watcher():
    return _watcher


async def get_placement_config() -> PlacementConfig:
    """FastAPI dependency — returns current in-memory config for this worker."""
    return await get_loader().get()
