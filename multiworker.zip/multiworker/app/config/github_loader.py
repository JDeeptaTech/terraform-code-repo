"""
app/config/github_loader.py
────────────────────────────
GitHub config loader — multi-worker safe.

Changes from single-worker version:
  - set_ref() also publishes a PostgreSQL NOTIFY after reloading
  - refresh() is guarded by asyncio.Lock (one in-flight fetch per worker)
  - Background refresh task is intentionally kept (TTL fallback if NOTIFY missed)
  - Each worker independently fetches from GitHub — no shared fetch coordination
    (with ETags, 304 Not Modified responses are free vs rate limit)
"""

from __future__ import annotations

import asyncio
import base64
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Callable, Awaitable, List, Optional

import httpx

from app.config.schema import PlacementConfig, parse_config

logger = logging.getLogger(__name__)


@dataclass
class CachedConfig:
    config:     PlacementConfig
    raw:        str
    sha:        str
    ref:        str
    fetched_at: float
    etag:       Optional[str] = None


@dataclass
class PromotionRecord:
    previous_ref: Optional[str]
    current_ref:  str
    sha:          str
    reason:       str
    worker_id:    str
    timestamp:    float = field(default_factory=time.time)


class GitHubConfigLoader:

    GITHUB_API = "https://api.github.com"

    def __init__(
        self,
        owner:            str,
        repo:             str,
        path:             str,
        ref:              str = "main",
        token:            Optional[str] = None,
        ttl:              int = 60,
        refresh_interval: int = 60,
        on_change:        Optional[Callable[[PlacementConfig, str], Awaitable[None]]] = None,
    ):
        self._owner    = owner
        self._repo     = repo
        self._path     = path.lstrip("/")
        self._ref      = ref
        self._ttl      = ttl
        self._interval = refresh_interval
        self._on_change = on_change
        self._worker_id = str(os.getpid())

        self._cache:      Optional[CachedConfig]    = None
        self._lock:       asyncio.Lock              = asyncio.Lock()
        self._task:       Optional[asyncio.Task]    = None
        self._promotions: List[PromotionRecord]     = []

        # sync_bus is injected after creation (set in registry.init)
        self._sync_bus = None

        headers = {
            "Accept":               "application/vnd.github.v3+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"

        self._client = httpx.AsyncClient(
            base_url=self.GITHUB_API,
            headers=headers,
            timeout=httpx.Timeout(connect=5.0, read=10.0, write=5.0, pool=5.0),
        )

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        logger.info(
            "GitHubConfigLoader starting",
            extra={"repo": f"{self._owner}/{self._repo}",
                   "path": self._path, "ref": self._ref,
                   "worker": self._worker_id},
        )
        await self.refresh(force=True)
        self._task = asyncio.create_task(
            self._bg_refresh(), name=f"github-config-refresh-{self._worker_id}"
        )

    async def stop(self) -> None:
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        await self._client.aclose()
        logger.info("GitHubConfigLoader stopped (worker=%s)", self._worker_id)

    # ── Public ─────────────────────────────────────────────────────────────────

    async def get(self) -> PlacementConfig:
        if self._cache is None:
            await self.refresh(force=True)
        elif self._ttl > 0 and (time.monotonic() - self._cache.fetched_at) > self._ttl:
            await self.refresh()
        return self._cache.config

    async def set_ref(self, new_ref: str, reason: str = "promotion") -> bool:
        """
        Switch active ref and reload.
        After successful reload, publishes a PostgreSQL NOTIFY
        so all other workers pick it up immediately.
        """
        previous_ref = self._ref
        self._ref    = new_ref

        changed = await self.refresh(force=True)

        sha = self._cache.sha if self._cache else "unknown"

        self._promotions.append(PromotionRecord(
            previous_ref=previous_ref,
            current_ref=new_ref,
            sha=sha[:8] if sha else "unknown",
            reason=reason,
            worker_id=self._worker_id,
        ))
        if len(self._promotions) > 50:
            self._promotions = self._promotions[-50:]

        # ── Publish to other workers ────────────────────────────────────────
        if self._sync_bus:
            await self._sync_bus.publish(
                ref=new_ref,
                sha=sha if sha else "unknown",
                reason=reason,
            )

        return changed

    async def refresh(self, force: bool = False) -> bool:
        async with self._lock:
            try:
                raw, sha, etag = await self._fetch()
            except Exception as exc:
                logger.error("GitHub fetch failed (worker=%s): %s", self._worker_id, exc,
                             exc_info=True)
                if self._cache:
                    return False
                raise RuntimeError(f"Initial fetch failed: {exc}") from exc

            if (not force
                    and self._cache
                    and self._cache.sha == sha
                    and self._cache.ref == self._ref):
                self._cache.fetched_at = time.monotonic()
                return False

            try:
                new_config = parse_config(raw, source_path=self._path)
            except Exception as exc:
                logger.error("Config parse error: %s", exc)
                return False

            prev_sha = self._cache.sha[:8] if self._cache else "none"
            self._cache = CachedConfig(
                config=new_config, raw=raw, sha=sha,
                ref=self._ref, fetched_at=time.monotonic(), etag=etag,
            )

            logger.info("Config loaded",
                        extra={"sha": sha[:8], "prev": prev_sha,
                               "ref": self._ref, "worker": self._worker_id})

            if self._on_change and prev_sha != "none":
                try:
                    await self._on_change(new_config, self._ref)
                except Exception as exc:
                    logger.error("on_change error: %s", exc)

            return True

    @property
    def active_ref(self) -> str:
        return self._ref

    @property
    def promotion_history(self) -> List[PromotionRecord]:
        return list(self._promotions)

    @property
    def cache_info(self) -> dict:
        if not self._cache:
            return {"loaded": False, "worker": self._worker_id}
        age = time.monotonic() - self._cache.fetched_at
        return {
            "loaded":      True,
            "ref":         self._cache.ref,
            "sha":         self._cache.sha[:8],
            "age_seconds": round(age, 1),
            "ttl_seconds": self._ttl,
            "stale":       age > self._ttl,
            "worker":      self._worker_id,
            "repo":        f"{self._owner}/{self._repo}",
            "path":        self._path,
        }

    # ── Internal ───────────────────────────────────────────────────────────────

    async def _fetch(self) -> tuple[str, str, Optional[str]]:
        url     = f"/repos/{self._owner}/{self._repo}/contents/{self._path}"
        params  = {"ref": self._ref}
        headers = {}

        if self._cache and self._cache.etag and self._cache.ref == self._ref:
            headers["If-None-Match"] = self._cache.etag

        response = await self._client.get(url, params=params, headers=headers)

        if response.status_code == 304:
            return self._cache.raw, self._cache.sha, self._cache.etag
        if response.status_code == 404:
            raise FileNotFoundError(
                f"Not found: {self._owner}/{self._repo}/{self._path}@{self._ref}"
            )
        if response.status_code == 401:
            raise PermissionError("GitHub API: invalid or expired token")
        if response.status_code == 403:
            remaining = response.headers.get("X-RateLimit-Remaining", "?")
            reset     = response.headers.get("X-RateLimit-Reset", "?")
            raise PermissionError(
                f"GitHub rate limited (remaining={remaining} reset={reset})"
            )

        response.raise_for_status()
        data    = response.json()
        content = base64.b64decode(data["content"]).decode("utf-8")
        return content, data["sha"], response.headers.get("ETag")

    async def _bg_refresh(self) -> None:
        """TTL-based background refresh — fallback if NOTIFY is missed."""
        while True:
            try:
                await asyncio.sleep(self._interval)
                await self.refresh()
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.error("Background refresh error: %s", exc)
