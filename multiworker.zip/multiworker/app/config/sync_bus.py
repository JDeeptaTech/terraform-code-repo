"""
app/config/sync_bus.py
───────────────────────
PostgreSQL LISTEN/NOTIFY cross-worker sync bus.

Why PostgreSQL instead of Redis/file IPC:
  - You already have it — zero extra infrastructure
  - NOTIFY is delivered within ~5ms to all listening workers
  - asyncpg has first-class LISTEN support
  - Survives pod restarts — no message loss concern (config is pulled, not pushed)

How it works:
  Publisher  (webhook receiver worker):
    After loading new config → pg_notify('placement_config_updated', payload_json)

  Listener   (every other worker):
    Maintains a dedicated asyncpg connection subscribed to the channel.
    On NOTIFY received → immediately calls loader.refresh(force=True)
    If the dedicated listener connection drops → auto-reconnects with back-off.

Channel:   placement_config_updated
Payload:   JSON {"ref": "v1.4.0", "sha": "abc123", "reason": "webhook:release"}
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Callable, Awaitable, Optional

import asyncpg

logger = logging.getLogger(__name__)

CHANNEL = "placement_config_updated"


class ConfigSyncBus:
    """
    PostgreSQL LISTEN/NOTIFY bus for cross-worker config synchronisation.

    Each worker runs one instance:
      - All workers LISTEN on the channel
      - The worker that handles a webhook also publishes a NOTIFY
      - All other workers receive it and refresh their local cache

    Parameters
    ----------
    database_url    PostgreSQL DSN (asyncpg format, NOT sqlalchemy format)
    on_notify       Async callback invoked when a NOTIFY is received.
                    Receives the parsed payload dict.
    worker_id       Identifier for log messages (e.g. PID)
    reconnect_delay Seconds to wait before reconnecting after a dropped connection
    """

    def __init__(
        self,
        database_url:    str,
        on_notify:       Callable[[dict], Awaitable[None]],
        worker_id:       Optional[str] = None,
        reconnect_delay: float = 5.0,
    ):
        # asyncpg uses postgresql:// not postgresql+asyncpg://
        self._dsn            = _to_asyncpg_dsn(database_url)
        self._on_notify      = on_notify
        self._worker_id      = worker_id or str(os.getpid())
        self._reconnect_delay = reconnect_delay
        self._conn:   Optional[asyncpg.Connection] = None
        self._task:   Optional[asyncio.Task]       = None
        self._closed: bool                         = False

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Connect and start listening. Launches background reconnect loop."""
        await self._connect()
        self._task = asyncio.create_task(
            self._listen_loop(),
            name=f"pg-notify-listener-{self._worker_id}",
        )
        logger.info(
            "ConfigSyncBus listening",
            extra={"channel": CHANNEL, "worker_id": self._worker_id},
        )

    async def stop(self) -> None:
        """Stop listening and close connection."""
        self._closed = True
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self._conn and not self._conn.is_closed():
            await self._conn.close()
        logger.info("ConfigSyncBus stopped (worker=%s)", self._worker_id)

    # ── Publish ────────────────────────────────────────────────────────────────

    async def publish(self, ref: str, sha: str, reason: str) -> None:
        """
        Notify all other workers that config has changed.
        Uses a short-lived connection so the listener connection stays clean.
        """
        payload = json.dumps({"ref": ref, "sha": sha, "reason": reason,
                               "from_worker": self._worker_id,
                               "timestamp": time.time()})
        try:
            conn = await asyncpg.connect(self._dsn, timeout=5)
            try:
                await conn.execute(f"SELECT pg_notify($1, $2)", CHANNEL, payload)
                logger.info(
                    "Config NOTIFY published",
                    extra={"channel": CHANNEL, "ref": ref, "sha": sha[:8], "reason": reason},
                )
            finally:
                await conn.close()
        except Exception as exc:
            # Non-fatal — other workers will catch up via TTL-based polling
            logger.warning("Failed to publish config NOTIFY: %s", exc)

    # ── Internal ───────────────────────────────────────────────────────────────

    async def _connect(self) -> None:
        """Establish the dedicated listener connection."""
        self._conn = await asyncpg.connect(self._dsn, timeout=10)

        # Register NOTIFY handler
        await self._conn.add_listener(CHANNEL, self._handle_notification)

        logger.debug(
            "LISTEN connection established (worker=%s channel=%s)",
            self._worker_id, CHANNEL,
        )

    async def _handle_notification(
        self,
        connection: asyncpg.Connection,
        pid:        int,
        channel:    str,
        payload:    str,
    ) -> None:
        """
        Called by asyncpg when a NOTIFY arrives on our channel.
        Runs in the event loop — must not block.
        """
        try:
            data = json.loads(payload) if payload else {}
        except json.JSONDecodeError:
            data = {"raw": payload}

        from_worker = data.get("from_worker", "unknown")
        ref         = data.get("ref", "unknown")
        reason      = data.get("reason", "notify")

        # Skip notifications we published ourselves
        if from_worker == self._worker_id:
            logger.debug("Ignoring self-published NOTIFY (ref=%s)", ref)
            return

        logger.info(
            "Config NOTIFY received — reloading",
            extra={
                "from_worker": from_worker,
                "ref":         ref,
                "reason":      reason,
                "worker_id":   self._worker_id,
            },
        )

        try:
            await self._on_notify(data)
        except Exception as exc:
            logger.error("on_notify handler error: %s", exc)

    async def _listen_loop(self) -> None:
        """
        Keep the listener connection alive.
        Reconnects automatically if the connection drops.
        """
        while not self._closed:
            try:
                # asyncpg connection is alive as long as we hold it.
                # We just need to yield to the event loop periodically
                # so the NOTIFY callbacks can fire.
                if self._conn.is_closed():
                    raise ConnectionError("Listener connection closed unexpectedly")

                # Heartbeat: send a no-op query every 30s to keep the connection alive
                await asyncio.sleep(30)
                await self._conn.execute("SELECT 1")

            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.warning(
                    "Listener connection lost, reconnecting in %ss: %s",
                    self._reconnect_delay, exc,
                )
                if self._conn and not self._conn.is_closed():
                    try:
                        await self._conn.close()
                    except Exception:
                        pass

                if self._closed:
                    return

                await asyncio.sleep(self._reconnect_delay)

                try:
                    await self._connect()
                    logger.info("Listener reconnected (worker=%s)", self._worker_id)
                except Exception as reconnect_exc:
                    logger.error("Reconnect failed: %s", reconnect_exc)


def _to_asyncpg_dsn(sqlalchemy_url: str) -> str:
    """
    Convert SQLAlchemy asyncpg DSN to plain asyncpg DSN.
    postgresql+asyncpg://user:pass@host/db  →  postgresql://user:pass@host/db
    """
    return sqlalchemy_url.replace("postgresql+asyncpg://", "postgresql://")
