"""
app/config/schema.py
─────────────────────
Pydantic models that define the structure of your placement config YAML/JSON
stored in GitHub.

Expected GitHub file layout (config/placement.yaml):
─────────────────────────────────────────────────────
  version: "1.0"

  scoring:
    weights:
      compute:   0.50
      network:   0.25
      datastore: 0.25
    datastore_target_utilisation: 0.75
    cluster_headroom_target:      0.20

  defaults:
    strategy: best_fit
    top_n:    3
    ha_required: true

  environments:
    prod:
      cluster_tags:
        must_have: ["prod", "ocp-virt"]
        exclude:   ["maintenance", "decommissioned"]
      network_tags:
        must_have: ["vlan-prod"]
        exclude:   ["deprecated", "test-only"]
      datastore_tags:
        must_have: ["prod-storage"]
        exclude:   ["archive"]
      datastore_constraints:
        min_free_gb:      100
        min_free_percent: 15.0

    dev:
      cluster_tags:
        must_have: ["dev", "ocp-virt"]
      network_tags:
        must_have: ["vlan-dev"]
      datastore_tags:
        must_have: ["dev-storage"]
      datastore_constraints:
        min_free_gb:      10
        min_free_percent: 5.0

  workload_profiles:
    gpu:
      cluster_tags:
        any_of: ["gpu-enabled"]
      prefer_tags: ["high-memory", "nvlink"]
    memory_intensive:
      prefer_tags: ["high-memory", "numa-optimised"]
    compute_intensive:
      prefer_tags: ["high-cpu", "avx512"]
─────────────────────────────────────────────────────
"""

from __future__ import annotations

from typing import Dict, List, Optional
from pydantic import BaseModel, Field, field_validator, model_validator


# ── Tag rules ─────────────────────────────────────────────────────────────────

class TagRules(BaseModel):
    must_have: List[str] = Field(default_factory=list)
    any_of:    List[str] = Field(default_factory=list)
    exclude:   List[str] = Field(default_factory=list)


# ── Scoring ────────────────────────────────────────────────────────────────────

class ScoringWeights(BaseModel):
    compute:   float = Field(default=0.50, ge=0.0, le=1.0)
    network:   float = Field(default=0.25, ge=0.0, le=1.0)
    datastore: float = Field(default=0.25, ge=0.0, le=1.0)

    @model_validator(mode="after")
    def weights_sum_to_one(self) -> "ScoringWeights":
        total = self.compute + self.network + self.datastore
        if abs(total - 1.0) > 0.001:
            raise ValueError(
                f"Scoring weights must sum to 1.0, got {total:.3f} "
                f"(compute={self.compute} + network={self.network} + datastore={self.datastore})"
            )
        return self


class ScoringConfig(BaseModel):
    weights:                       ScoringWeights = Field(default_factory=ScoringWeights)
    datastore_target_utilisation:  float = Field(default=0.75, ge=0.0, le=1.0)
    cluster_headroom_target:       float = Field(default=0.20, ge=0.0, le=1.0)


# ── Defaults ───────────────────────────────────────────────────────────────────

class DefaultsConfig(BaseModel):
    strategy:    str  = "best_fit"
    top_n:       int  = Field(default=3, ge=1, le=10)
    ha_required: bool = True

    @field_validator("strategy")
    @classmethod
    def valid_strategy(cls, v: str) -> str:
        allowed = {"best_fit", "spread", "packed"}
        if v not in allowed:
            raise ValueError(f"strategy must be one of {allowed}, got '{v}'")
        return v


# ── Environment config ─────────────────────────────────────────────────────────

class DatastoreConstraints(BaseModel):
    min_free_gb:      Optional[float] = Field(default=None, ge=0)
    min_free_percent: Optional[float] = Field(default=None, ge=0, le=100)


class EnvironmentConfig(BaseModel):
    cluster_tags:           TagRules            = Field(default_factory=TagRules)
    cluster_prefer_tags:    List[str]           = Field(default_factory=list)
    network_tags:           TagRules            = Field(default_factory=TagRules)
    network_prefer_tags:    List[str]           = Field(default_factory=list)
    datastore_tags:         TagRules            = Field(default_factory=TagRules)
    datastore_prefer_tags:  List[str]           = Field(default_factory=list)
    datastore_constraints:  DatastoreConstraints = Field(default_factory=DatastoreConstraints)

    # Environment-level overrides (optional — falls back to top-level defaults)
    strategy:    Optional[str]  = None
    ha_required: Optional[bool] = None


# ── Workload profile overrides ─────────────────────────────────────────────────

class WorkloadProfileConfig(BaseModel):
    """
    Workload-type-specific tag additions.
    Merged on top of the environment config at request time.
    """
    cluster_tags:          TagRules  = Field(default_factory=TagRules)
    cluster_prefer_tags:   List[str] = Field(default_factory=list)
    network_tags:          TagRules  = Field(default_factory=TagRules)
    network_prefer_tags:   List[str] = Field(default_factory=list)
    datastore_tags:        TagRules  = Field(default_factory=TagRules)
    datastore_prefer_tags: List[str] = Field(default_factory=list)


# ── Root config ────────────────────────────────────────────────────────────────

class PlacementConfig(BaseModel):
    version:           str                               = "1.0"
    scoring:           ScoringConfig                     = Field(default_factory=ScoringConfig)
    defaults:          DefaultsConfig                    = Field(default_factory=DefaultsConfig)
    environments:      Dict[str, EnvironmentConfig]      = Field(default_factory=dict)
    workload_profiles: Dict[str, WorkloadProfileConfig]  = Field(default_factory=dict)

    def get_environment(self, env: str) -> EnvironmentConfig:
        """Return env config, falling back to empty config if env not defined."""
        return self.environments.get(env, EnvironmentConfig())

    def get_workload_profile(self, workload_type: str) -> WorkloadProfileConfig:
        """Return workload type overrides, falling back to empty profile."""
        return self.workload_profiles.get(workload_type, WorkloadProfileConfig())

    def merge_selectors(
        self,
        env: str,
        workload_type: str,
    ) -> "MergedSelectors":
        """
        Produce a merged selector set for a given environment + workload type.

        Merge order (later wins):
          1. Environment config (base tags for this environment)
          2. Workload profile overrides (type-specific additions)

        Tag merging rules:
          must_have  : union of all lists
          any_of     : union of all lists
          exclude    : union of all lists (exclusions always accumulate)
          prefer_tags: union of all lists
        """
        env_cfg  = self.get_environment(env)
        wl_cfg   = self.get_workload_profile(workload_type)

        return MergedSelectors(
            cluster_must_have  = _union(env_cfg.cluster_tags.must_have,  wl_cfg.cluster_tags.must_have),
            cluster_any_of     = _union(env_cfg.cluster_tags.any_of,     wl_cfg.cluster_tags.any_of),
            cluster_exclude    = _union(env_cfg.cluster_tags.exclude,     wl_cfg.cluster_tags.exclude),
            cluster_prefer     = _union(env_cfg.cluster_prefer_tags,      wl_cfg.cluster_prefer_tags),

            network_must_have  = _union(env_cfg.network_tags.must_have,   wl_cfg.network_tags.must_have),
            network_any_of     = _union(env_cfg.network_tags.any_of,      wl_cfg.network_tags.any_of),
            network_exclude    = _union(env_cfg.network_tags.exclude,      wl_cfg.network_tags.exclude),
            network_prefer     = _union(env_cfg.network_prefer_tags,       wl_cfg.network_prefer_tags),

            datastore_must_have = _union(env_cfg.datastore_tags.must_have, wl_cfg.datastore_tags.must_have),
            datastore_any_of    = _union(env_cfg.datastore_tags.any_of,    wl_cfg.datastore_tags.any_of),
            datastore_exclude   = _union(env_cfg.datastore_tags.exclude,   wl_cfg.datastore_tags.exclude),
            datastore_prefer    = _union(env_cfg.datastore_prefer_tags,    wl_cfg.datastore_prefer_tags),

            min_free_gb         = env_cfg.datastore_constraints.min_free_gb,
            min_free_percent    = env_cfg.datastore_constraints.min_free_percent,

            strategy    = env_cfg.strategy or self.defaults.strategy,
            ha_required = env_cfg.ha_required if env_cfg.ha_required is not None else self.defaults.ha_required,
        )


class MergedSelectors(BaseModel):
    """Fully resolved selectors for a specific environment + workload combination."""
    cluster_must_have:   List[str]
    cluster_any_of:      List[str]
    cluster_exclude:     List[str]
    cluster_prefer:      List[str]

    network_must_have:   List[str]
    network_any_of:      List[str]
    network_exclude:     List[str]
    network_prefer:      List[str]

    datastore_must_have: List[str]
    datastore_any_of:    List[str]
    datastore_exclude:   List[str]
    datastore_prefer:    List[str]

    min_free_gb:         Optional[float]
    min_free_percent:    Optional[float]

    strategy:            str
    ha_required:         bool


# ── Parser ─────────────────────────────────────────────────────────────────────

def parse_config(content: str, source_path: str = "") -> PlacementConfig:
    """
    Parse YAML or JSON config string into PlacementConfig.
    File type detected from source_path extension; defaults to YAML.
    """
    if source_path.endswith(".json"):
        data = _parse_json(content)
    else:
        data = _parse_yaml(content)

    return PlacementConfig.model_validate(data)


def _parse_yaml(content: str) -> dict:
    try:
        import yaml
        return yaml.safe_load(content) or {}
    except ImportError:
        raise ImportError("PyYAML is required for YAML config: pip install pyyaml")


def _parse_json(content: str) -> dict:
    import json
    return json.loads(content)


def _union(*lists: List[str]) -> List[str]:
    """Deduplicated union of multiple lists, preserving first-seen order."""
    seen = set()
    result = []
    for lst in lists:
        for item in lst:
            if item not in seen:
                seen.add(item)
                result.append(item)
    return result
