"""
app/config/release_watcher.py
──────────────────────────────
Auto-discovers new config versions from GitHub tags and releases.

Strategy options (set via GITHUB_CONFIG_STRATEGY env var):

  latest_release  (default)
    Tracks the latest published GitHub Release.
    Stable — only promotes when you explicitly publish a release.
    Ignores pre-releases unless GITHUB_ALLOW_PRERELEASE=true.

  semver_range
    Tracks the highest tag matching a semver range (e.g. ">=1.0.0 <2.0.0").
    Useful for major-version pinning.

  track_branch
    Tracks the HEAD of a specific branch (original behaviour).
    No version management — every push is picked up.

  pinned
    Fixed to an exact tag or SHA. Never auto-promotes.
    Override via POST /v1/config/promote.

Discovery flow:

  ┌─────────────────────────────────────────────────────────┐
  │  GitHub Events (webhook)        OR  Polling (fallback)  │
  │                                                         │
  │  release published  ──────────────────────┐            │
  │  tag created        ──────────────────────┤            │
  │  push to branch     ──────────────────────┤            │
  │                                           ▼            │
  │                              ReleaseWatcher.evaluate()  │
  │                                           │            │
  │                              Is new ref better?         │
  │                                   │                    │
  │                          yes ─────┤  no ── ignore      │
  │                                   ▼                    │
  │                         GitHubConfigLoader.set_ref()   │
  │                         + reload config                │
  │                         + emit on_promote callback     │
  └─────────────────────────────────────────────────────────┘
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Awaitable, List, Optional

import httpx

logger = logging.getLogger(__name__)


# ── Enums ──────────────────────────────────────────────────────────────────────

class ConfigStrategy(str, Enum):
    LATEST_RELEASE = "latest_release"
    SEMVER_RANGE   = "semver_range"
    TRACK_BRANCH   = "track_branch"
    PINNED         = "pinned"


# ── Data models ────────────────────────────────────────────────────────────────

@dataclass
class GitRef:
    """A resolved GitHub ref (tag, release, or branch)."""
    name:        str            # tag name, branch name, or SHA
    ref_type:    str            # "tag" | "release" | "branch" | "sha"
    sha:         str            # commit SHA this ref points to
    semver:      Optional[tuple] = None   # (major, minor, patch) if parseable
    prerelease:  bool = False
    published_at: Optional[str] = None

    def __str__(self) -> str:
        return f"{self.ref_type}:{self.name}@{self.sha[:8]}"


@dataclass
class PromotionEvent:
    """Emitted when the active config ref changes."""
    previous:   Optional[GitRef]
    current:    GitRef
    reason:     str              # "release_published" | "tag_created" | "webhook_push" | "manual"
    strategy:   str


# ── Semver helpers ─────────────────────────────────────────────────────────────

def parse_semver(tag: str) -> Optional[tuple]:
    """
    Parse a semver string into (major, minor, patch).
    Accepts: 1.2.3  v1.2.3  release-1.2.3  config/1.2.3
    Returns None if not parseable.
    """
    match = re.search(r"(\d+)\.(\d+)\.(\d+)", tag)
    if match:
        return (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    return None


def satisfies_range(version: tuple, range_str: str) -> bool:
    """
    Simple semver range check.
    Supports: >=1.0.0, <=2.0.0, >1.0.0, <2.0.0, ==1.2.3, ^1.0.0, ~1.2.0

    Example: satisfies_range((1,3,0), ">=1.0.0 <2.0.0") → True
    """
    if not range_str:
        return True

    parts = range_str.strip().split()
    for part in parts:
        match = re.match(r"([><=^~!]+)(\d+)\.(\d+)\.(\d+)", part)
        if not match:
            continue
        op       = match.group(1)
        required = (int(match.group(2)), int(match.group(3)), int(match.group(4)))

        if op == ">="  and not (version >= required): return False
        if op == "<="  and not (version <= required): return False
        if op == ">"   and not (version >  required): return False
        if op == "<"   and not (version <  required): return False
        if op == "=="  and not (version == required): return False
        if op == "!="  and not (version != required): return False
        if op == "^":
            # Compatible with same major
            if version[0] != required[0]: return False
            if version < required:         return False
        if op == "~":
            # Compatible with same major.minor
            if version[:2] != required[:2]: return False
            if version < required:           return False

    return True


# ── Release watcher ────────────────────────────────────────────────────────────

class ReleaseWatcher:
    """
    Watches a GitHub repository for tag/release changes and
    promotes the config loader to the best matching ref.

    Parameters
    ----------
    owner            GitHub org/user
    repo             Repository name
    strategy         How to select the active ref
    semver_range     Range constraint for SEMVER_RANGE strategy  e.g. ">=1.0.0 <2.0.0"
    allow_prerelease Include pre-release GitHub releases
    poll_interval    Seconds between polling GitHub for new refs (0 = webhook-only)
    token            GitHub PAT
    on_promote       Async callback called when the active ref changes
    """

    GITHUB_API = "https://api.github.com"

    def __init__(
        self,
        owner:            str,
        repo:             str,
        strategy:         ConfigStrategy = ConfigStrategy.LATEST_RELEASE,
        semver_range:     str = "",
        allow_prerelease: bool = False,
        poll_interval:    int = 300,        # 5 min default
        token:            Optional[str] = None,
        on_promote:       Optional[Callable[[PromotionEvent], Awaitable[None]]] = None,
    ):
        self._owner            = owner
        self._repo             = repo
        self._strategy         = strategy
        self._semver_range     = semver_range
        self._allow_prerelease = allow_prerelease
        self._poll_interval    = poll_interval
        self._on_promote       = on_promote

        self._active_ref:   Optional[GitRef]  = None
        self._known_refs:   List[GitRef]       = []
        self._poll_task:    Optional[asyncio.Task] = None

        headers = {"Accept": "application/vnd.github.v3+json",
                   "X-GitHub-Api-Version": "2022-11-28"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        self._client = httpx.AsyncClient(
            base_url=self.GITHUB_API,
            headers=headers,
            timeout=httpx.Timeout(connect=5.0, read=15.0, write=5.0, pool=5.0),
        )

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> GitRef:
        """
        Discover initial best ref and start background polling.
        Returns the selected ref so the config loader can use it.
        """
        ref = await self._discover_best_ref()
        self._active_ref = ref

        logger.info(
            "ReleaseWatcher started",
            extra={
                "strategy":    self._strategy.value,
                "active_ref":  str(ref),
                "semver_range": self._semver_range,
            },
        )

        if self._poll_interval > 0:
            self._poll_task = asyncio.create_task(
                self._poll_loop(),
                name="github-release-watcher",
            )

        return ref

    async def stop(self) -> None:
        if self._poll_task and not self._poll_task.done():
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
        await self._client.aclose()

    # ── Public ─────────────────────────────────────────────────────────────────

    @property
    def active_ref(self) -> Optional[GitRef]:
        return self._active_ref

    @property
    def known_refs(self) -> List[GitRef]:
        return list(self._known_refs)

    async def handle_webhook_event(
        self,
        event_type: str,
        payload:    dict,
        reason:     str = "webhook",
    ) -> Optional[PromotionEvent]:
        """
        Process a GitHub webhook event.
        Called by POST /v1/config/refresh with the parsed webhook payload.

        Handles:
          release   (action: published)
          create    (ref_type: tag)
          push      (for track_branch strategy)
        """
        logger.info(
            "Webhook event received",
            extra={"event": event_type, "reason": reason},
        )

        should_check = False

        if event_type == "release":
            action = payload.get("action", "")
            if action == "published":
                should_check = True
                logger.info("Release published: %s", payload.get("release", {}).get("tag_name"))

        elif event_type == "create":
            ref_type = payload.get("ref_type", "")
            if ref_type == "tag":
                should_check = True
                logger.info("Tag created: %s", payload.get("ref"))

        elif event_type == "push":
            # Only relevant for track_branch strategy
            if self._strategy == ConfigStrategy.TRACK_BRANCH:
                branch = payload.get("ref", "").replace("refs/heads/", "")
                should_check = True
                logger.info("Push to branch: %s", branch)

        if not should_check:
            return None

        return await self._check_for_promotion(reason=reason)

    async def check_now(self, reason: str = "manual") -> Optional[PromotionEvent]:
        """Force an immediate check for a better ref."""
        return await self._check_for_promotion(reason=reason)

    async def promote_to(
        self,
        ref_name: str,
        reason:   str = "manual",
    ) -> Optional[PromotionEvent]:
        """
        Manually promote to a specific tag/branch/SHA.
        Used by POST /v1/config/promote.
        """
        sha = await self._resolve_sha(ref_name)
        new_ref = GitRef(
            name=ref_name,
            ref_type="manual",
            sha=sha,
            semver=parse_semver(ref_name),
        )
        return await self._promote(new_ref, reason=reason)

    # ── Discovery ──────────────────────────────────────────────────────────────

    async def _discover_best_ref(self) -> GitRef:
        if self._strategy == ConfigStrategy.LATEST_RELEASE:
            return await self._get_latest_release()

        elif self._strategy == ConfigStrategy.SEMVER_RANGE:
            return await self._get_best_semver_tag()

        elif self._strategy == ConfigStrategy.TRACK_BRANCH:
            # Caller sets the branch — watcher just monitors it
            # Return a dummy ref; loader uses the configured branch
            return GitRef(name="branch", ref_type="branch", sha="head")

        elif self._strategy == ConfigStrategy.PINNED:
            # No auto-discovery — return current active or raise
            if self._active_ref:
                return self._active_ref
            raise RuntimeError("PINNED strategy requires an explicit ref set via promote_to()")

        raise ValueError(f"Unknown strategy: {self._strategy}")

    async def _get_latest_release(self) -> GitRef:
        """Fetch the latest published GitHub Release."""
        try:
            resp = await self._client.get(
                f"/repos/{self._owner}/{self._repo}/releases/latest"
            )
            if resp.status_code == 404:
                logger.warning("No releases found — falling back to tags")
                return await self._get_best_semver_tag()

            resp.raise_for_status()
            data = resp.json()

            if data.get("prerelease") and not self._allow_prerelease:
                # Latest is a pre-release but we don't allow it — find last stable
                return await self._get_latest_stable_release()

            tag  = data["tag_name"]
            sha  = await self._resolve_sha(tag)
            return GitRef(
                name=tag,
                ref_type="release",
                sha=sha,
                semver=parse_semver(tag),
                prerelease=data.get("prerelease", False),
                published_at=data.get("published_at"),
            )
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Failed to fetch latest release: {exc}") from exc

    async def _get_latest_stable_release(self) -> GitRef:
        """Fetch all releases and return the latest non-pre-release."""
        resp = await self._client.get(
            f"/repos/{self._owner}/{self._repo}/releases",
            params={"per_page": 20},
        )
        resp.raise_for_status()

        for release in resp.json():
            if not release.get("prerelease", False):
                tag = release["tag_name"]
                sha = await self._resolve_sha(tag)
                return GitRef(
                    name=tag,
                    ref_type="release",
                    sha=sha,
                    semver=parse_semver(tag),
                    prerelease=False,
                    published_at=release.get("published_at"),
                )

        raise RuntimeError("No stable releases found")

    async def _get_best_semver_tag(self) -> GitRef:
        """List all tags, parse semver, return highest matching range."""
        resp = await self._client.get(
            f"/repos/{self._owner}/{self._repo}/tags",
            params={"per_page": 100},
        )
        resp.raise_for_status()

        tags = resp.json()
        self._known_refs = []

        candidates: List[GitRef] = []
        for tag in tags:
            name   = tag["name"]
            semver = parse_semver(name)
            if semver is None:
                continue

            if self._semver_range and not satisfies_range(semver, self._semver_range):
                continue

            ref = GitRef(
                name=name,
                ref_type="tag",
                sha=tag["commit"]["sha"],
                semver=semver,
            )
            candidates.append(ref)
            self._known_refs.append(ref)

        if not candidates:
            raise RuntimeError(
                f"No tags found matching semver range '{self._semver_range}'"
            )

        # Sort descending — highest semver first
        candidates.sort(key=lambda r: r.semver, reverse=True)

        logger.info(
            "Semver tag discovery: %d candidates, selected %s",
            len(candidates), candidates[0].name,
        )

        return candidates[0]

    async def _resolve_sha(self, ref_name: str) -> str:
        """Resolve a tag/branch name to its commit SHA."""
        # Try as tag first (refs/tags/<name>)
        resp = await self._client.get(
            f"/repos/{self._owner}/{self._repo}/git/ref/tags/{ref_name}"
        )
        if resp.status_code == 200:
            data = resp.json()
            obj  = data.get("object", {})
            # Annotated tags point to a tag object, not a commit
            if obj.get("type") == "tag":
                tag_resp = await self._client.get(
                    f"/repos/{self._owner}/{self._repo}/git/tags/{obj['sha']}"
                )
                tag_resp.raise_for_status()
                return tag_resp.json()["object"]["sha"]
            return obj["sha"]

        # Try as branch
        resp = await self._client.get(
            f"/repos/{self._owner}/{self._repo}/git/ref/heads/{ref_name}"
        )
        if resp.status_code == 200:
            return resp.json()["object"]["sha"]

        # Assume it's already a SHA
        return ref_name

    # ── Promotion ──────────────────────────────────────────────────────────────

    async def _check_for_promotion(self, reason: str) -> Optional[PromotionEvent]:
        """Discover best ref and promote if it's better than the current one."""
        try:
            best = await self._discover_best_ref()
        except Exception as exc:
            logger.error("Failed to discover best ref: %s", exc)
            return None

        if self._is_better(best):
            return await self._promote(best, reason=reason)

        logger.debug(
            "No promotion: current %s >= candidate %s",
            self._active_ref, best,
        )
        return None

    def _is_better(self, candidate: GitRef) -> bool:
        """
        Determine if candidate should replace the active ref.

        Rules:
          LATEST_RELEASE / SEMVER_RANGE : newer semver wins
          TRACK_BRANCH                  : different SHA wins
          PINNED                        : never auto-promoted
        """
        if self._strategy == ConfigStrategy.PINNED:
            return False

        if self._active_ref is None:
            return True

        if self._active_ref.sha == candidate.sha:
            return False  # same commit — nothing to do

        if self._strategy == ConfigStrategy.TRACK_BRANCH:
            # Any SHA change on the branch is an improvement
            return True

        # Semver comparison
        if candidate.semver and self._active_ref.semver:
            return candidate.semver > self._active_ref.semver

        # Can't compare — accept the new one
        return True

    async def _promote(self, new_ref: GitRef, reason: str) -> PromotionEvent:
        event = PromotionEvent(
            previous=self._active_ref,
            current=new_ref,
            reason=reason,
            strategy=self._strategy.value,
        )
        self._active_ref = new_ref

        logger.warning(
            "Config ref promoted",
            extra={
                "previous": str(event.previous),
                "current":  str(new_ref),
                "reason":   reason,
                "strategy": self._strategy.value,
            },
        )

        if self._on_promote:
            try:
                await self._on_promote(event)
            except Exception as exc:
                logger.error("on_promote callback error: %s", exc)

        return event

    # ── Background polling ─────────────────────────────────────────────────────

    async def _poll_loop(self) -> None:
        """Periodically check for new releases/tags (webhook fallback)."""
        while True:
            try:
                await asyncio.sleep(self._poll_interval)
                event = await self._check_for_promotion(reason="poll")
                if event:
                    logger.info(
                        "Polling promoted config: %s → %s",
                        event.previous, event.current,
                    )
            except asyncio.CancelledError:
                logger.info("Release watcher poll loop cancelled")
                return
            except Exception as exc:
                logger.error("Release watcher poll error: %s", exc)

    @property
    def status(self) -> dict:
        return {
            "strategy":        self._strategy.value,
            "semver_range":    self._semver_range,
            "allow_prerelease": self._allow_prerelease,
            "active_ref": {
                "name":         self._active_ref.name        if self._active_ref else None,
                "ref_type":     self._active_ref.ref_type    if self._active_ref else None,
                "sha":          self._active_ref.sha[:8]     if self._active_ref else None,
                "semver":       list(self._active_ref.semver) if self._active_ref and self._active_ref.semver else None,
                "prerelease":   self._active_ref.prerelease  if self._active_ref else None,
                "published_at": self._active_ref.published_at if self._active_ref else None,
            },
            "known_refs": [
                {"name": r.name, "semver": list(r.semver) if r.semver else None}
                for r in self._known_refs[:10]
            ],
            "poll_interval": self._poll_interval,
        }
