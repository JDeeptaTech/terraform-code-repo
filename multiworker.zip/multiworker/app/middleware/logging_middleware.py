"""app/middleware/logging_middleware.py"""
import logging
import time
import uuid
from contextvars import ContextVar
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

request_id_var: ContextVar[str] = ContextVar("request_id", default="")
logger = logging.getLogger("access")


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        req_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        request_id_var.set(req_id)
        start = time.monotonic()
        response = await call_next(request)
        ms = round((time.monotonic() - start) * 1000, 1)
        logger.info("%s %s %s %.1fms", request.method, request.url.path,
                    response.status_code, ms)
        if ms > 500:
            logger.warning("Slow request: %s %.1fms", request.url.path, ms)
        response.headers["X-Request-ID"] = req_id
        return response
