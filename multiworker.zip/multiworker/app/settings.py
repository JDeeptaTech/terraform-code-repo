"""
app/settings.py
────────────────
Key difference from 2-worker config:
  DB_POOL_SIZE and DB_MAX_OVERFLOW are halved.
  5 workers × (4+4) = 40 connections per pod vs 5×(10+10)=100.
"""
from typing import Optional
from pydantic_settings import BaseSettings
from app.config.release_watcher import ConfigStrategy


class Settings(BaseSettings):
    app_env:     str = "development"
    app_version: str = "1.0.0"
    log_level:   str = "INFO"

    database_url: str = (
        "postgresql+asyncpg://placement:placement@localhost:5432/placement_engine"
    )

    # ── DB pool — tuned for 5 workers ─────────────────────────────────────────
    # 5 workers × (4+4) max = 40 per pod.  3 pods = 120 total.
    # Plus 5 sync_bus listener connections = 125 per pod max.
    # Set PostgreSQL max_connections = 150.
    db_pool_size:     int  = 4        # was 10 in 2-worker config
    db_max_overflow:  int  = 4        # was 10
    db_pool_timeout:  int  = 30
    db_pool_recycle:  int  = 1800
    db_pool_pre_ping: bool = True
    db_echo:          bool = False

    # ── GitHub ─────────────────────────────────────────────────────────────────
    github_owner:            str            = "my-org"
    github_repo:             str            = "platform-config"
    github_config_path:      str            = "placement/config.yaml"
    github_ref:              str            = "main"
    github_token:            Optional[str]  = None
    github_webhook_secret:   Optional[str]  = None
    github_config_strategy:  ConfigStrategy = ConfigStrategy.LATEST_RELEASE
    github_semver_range:     str            = ""
    github_allow_prerelease: bool           = False

    config_ttl:              int = 60
    config_refresh_interval: int = 60
    release_poll_interval:   int = 300

    # ── Splunk ─────────────────────────────────────────────────────────────────
    splunk_hec_url:    Optional[str] = None
    splunk_hec_token:  Optional[str] = None
    splunk_index:      str           = "main"
    splunk_source:     str           = "placement-engine"
    splunk_verify_ssl: bool          = True

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


settings = Settings()
