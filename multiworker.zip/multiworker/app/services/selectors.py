"""
app/services/selectors.py
──────────────────────────
Cluster, network, and datastore selectors updated to consume
MergedSelectors resolved from GitHub config (not request body).
"""

import logging
from dataclasses import dataclass
from typing import List, Optional

from app.config.schema import MergedSelectors, ScoringConfig, TagRules
from app.db.models import Cluster, Network, Datastore
from app.engine.tag_matcher import parse_tags, parse_cluster_list, match_tags, TagMatchResult

logger = logging.getLogger(__name__)


# ── Shared result types ────────────────────────────────────────────────────────

@dataclass
class Rejected:
    name:   str
    reason: str


@dataclass
class ScoredCluster:
    cluster:        Cluster
    tag_result:     TagMatchResult
    resource_score: float
    total_score:    float


@dataclass
class ScoredNetwork:
    network:    Network
    tag_result: TagMatchResult
    score:      float
    reason:     str


@dataclass
class ScoredDatastore:
    datastore:      Datastore
    tag_result:     TagMatchResult
    score:          float
    free_gb_after:  float
    free_pct_after: float
    reason:         str


# ── Cluster selector ───────────────────────────────────────────────────────────

def select_clusters_with_selectors(
    clusters:       List[Cluster],
    selectors:      MergedSelectors,
    workload,                           # WorkloadProfile
    strategy:       str,
    scoring_config: ScoringConfig,
) -> tuple[List[ScoredCluster], List[Rejected]]:
    """
    Filter clusters using tag rules from GitHub config,
    then score surviving clusters.
    """
    tag_selector = TagRules(
        must_have=selectors.cluster_must_have,
        any_of=selectors.cluster_any_of,
        exclude=selectors.cluster_exclude,
    )
    accepted: List[ScoredCluster] = []
    rejected: List[Rejected]      = []

    for cluster in clusters:
        cluster_tags = parse_tags(cluster.tags)

        tag_result = match_tags(
            resource_tags=cluster_tags,
            selector=tag_selector,
            prefer_tags=selectors.cluster_prefer,
        )
        if not tag_result.passed:
            rejected.append(Rejected(cluster.name, f"Tag: {tag_result.reason}"))
            continue

        # Hard resource checks
        if cluster.available_cpu < workload.cpu_cores:
            rejected.append(Rejected(cluster.name,
                f"CPU: need {workload.cpu_cores}, have {cluster.available_cpu}"))
            continue

        if cluster.available_memory_gb < workload.memory_gb:
            rejected.append(Rejected(cluster.name,
                f"Memory: need {workload.memory_gb}GB, have {cluster.available_memory_gb}GB"))
            continue

        if selectors.ha_required and not cluster.ha_enabled:
            rejected.append(Rejected(cluster.name, "HA required, cluster HA disabled"))
            continue

        if workload.workload_type == "gpu" and cluster.gpu_count == 0:
            rejected.append(Rejected(cluster.name, "GPU workload, no GPUs on cluster"))
            continue

        resource_score = _score_cluster(cluster, workload, strategy, scoring_config)
        pref_bonus     = min(tag_result.preference_hits * 5, 20)
        gpu_bonus      = 15 if workload.workload_type == "gpu" and cluster.gpu_count > 0 else 0
        ha_bonus       = 5  if selectors.ha_required and cluster.ha_enabled else 0

        total = min(resource_score + pref_bonus + gpu_bonus + ha_bonus, 100.0)

        accepted.append(ScoredCluster(
            cluster=cluster,
            tag_result=tag_result,
            resource_score=resource_score,
            total_score=round(total, 2),
        ))

    accepted.sort(key=lambda x: x.total_score, reverse=True)
    return accepted, rejected


def _score_cluster(cluster, workload, strategy: str, scoring: ScoringConfig) -> float:
    cpu_ratio = cluster.available_cpu / max(cluster.total_cpu, 1)
    mem_ratio = cluster.available_memory_gb / max(cluster.total_memory_gb, 1)

    if strategy == "packed":
        return (1 - cpu_ratio) * 40 + (1 - mem_ratio) * 40
    elif strategy == "spread":
        return cpu_ratio * 40 + mem_ratio * 40
    else:  # best_fit
        t = scoring.cluster_headroom_target
        hc = (cluster.available_cpu - workload.cpu_cores) / max(cluster.total_cpu, 1)
        hm = (cluster.available_memory_gb - workload.memory_gb) / max(cluster.total_memory_gb, 1)
        fc = max(0.0, 1.0 - abs(hc - t) * 3)
        fm = max(0.0, 1.0 - abs(hm - t) * 3)
        return round(fc * 40 + fm * 40, 2)


# ── Network selector ───────────────────────────────────────────────────────────

def pick_best_network_with_selectors(
    networks:     List[Network],
    cluster_name: str,
    selectors:    MergedSelectors,
) -> Optional[ScoredNetwork]:
    tag_selector = TagRules(
        must_have=selectors.network_must_have,
        any_of=selectors.network_any_of,
        exclude=selectors.network_exclude,
    )
    results: List[ScoredNetwork] = []

    for net in networks:
        if cluster_name not in parse_cluster_list(net.available_on_clusters):
            continue

        tag_result = match_tags(
            resource_tags=parse_tags(net.tags),
            selector=tag_selector,
            prefer_tags=selectors.network_prefer,
        )
        if not tag_result.passed:
            continue

        pref_bonus = min(tag_result.preference_hits * 10, 40)
        score      = round(60 + pref_bonus, 2)
        reason     = f"Pref hits: {tag_result.preference_hits} (+{pref_bonus}pts)"

        results.append(ScoredNetwork(
            network=net,
            tag_result=tag_result,
            score=score,
            reason=reason,
        ))

    results.sort(key=lambda x: x.score, reverse=True)
    return results[0] if results else None


# ── Datastore selector ─────────────────────────────────────────────────────────

def pick_best_datastore_with_selectors(
    datastores:     List[Datastore],
    cluster_name:   str,
    selectors:      MergedSelectors,
    disk_needed:    float,
    scoring_config: ScoringConfig,
) -> Optional[ScoredDatastore]:
    tag_selector = TagRules(
        must_have=selectors.datastore_must_have,
        any_of=selectors.datastore_any_of,
        exclude=selectors.datastore_exclude,
    )
    results: List[ScoredDatastore] = []

    for ds in datastores:
        if cluster_name not in parse_cluster_list(ds.available_on_clusters):
            continue

        tag_result = match_tags(
            resource_tags=parse_tags(ds.tags),
            selector=tag_selector,
            prefer_tags=selectors.datastore_prefer,
        )
        if not tag_result.passed:
            continue

        # Hard capacity checks
        if ds.free_gb < disk_needed:
            continue

        free_after     = ds.free_gb - disk_needed
        free_pct_after = (free_after / max(ds.total_gb, 1)) * 100

        if selectors.min_free_gb is not None and free_after < selectors.min_free_gb:
            continue

        if selectors.min_free_percent is not None and free_pct_after < selectors.min_free_percent:
            continue

        # Score
        utilisation_after = (ds.used_gb + disk_needed) / max(ds.total_gb, 1)
        distance   = abs(utilisation_after - scoring_config.datastore_target_utilisation)
        cap_score  = max(0.0, 70.0 - (distance * 140))
        pref_bonus = min(tag_result.preference_hits * 10, 30)
        score      = round(cap_score + pref_bonus, 2)

        results.append(ScoredDatastore(
            datastore=ds,
            tag_result=tag_result,
            score=score,
            free_gb_after=round(free_after, 2),
            free_pct_after=round(free_pct_after, 2),
            reason=(
                f"Free after: {free_after:.1f}GB ({free_pct_after:.1f}%). "
                f"Pref hits: {tag_result.preference_hits} (+{pref_bonus}pts)."
            ),
        ))

    results.sort(key=lambda x: x.score, reverse=True)
    return results[0] if results else None
