"""app/logging/setup.py"""
import logging
import sys
from app.settings import settings

_splunk_handler = None


def setup_logging():
    level = getattr(logging, settings.log_level.upper(), logging.INFO)
    logging.basicConfig(
        stream=sys.stdout,
        level=level,
        format='{"time":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","msg":"%(message)s"}',
    )
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)


def get_splunk_handler():
    return _splunk_handler
