"""
app/main.py
────────────
Multi-worker FastAPI lifespan.

Gunicorn forks N worker processes AFTER the master starts.
Each worker runs its OWN lifespan independently — this is correct.
The sync_bus (PostgreSQL NOTIFY) keeps them synchronised.

Startup order per worker:
  1. setup_logging()
  2. ReleaseWatcher.start()     — discover best ref
  3. GitHubConfigLoader.start() — load config for that ref
  4. ConfigSyncBus.start()      — subscribe to cross-worker notifications
  5. DB tables (idempotent)
  6. Middleware + routers

Shutdown order per worker:
  1. watcher.stop()
  2. loader.stop()
  3. sync_bus.stop()
  4. dispose_engine()
  5. logging.shutdown()
"""

import logging
import logging as stdlib_logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.settings import settings
from app.config.github_loader import GitHubConfigLoader
from app.config.sync_bus import ConfigSyncBus
from app.config.release_watcher import ReleaseWatcher, ConfigStrategy, PromotionEvent
from app.config.schema import PlacementConfig
from app.config import registry
from app.logging.setup import setup_logging
from app.middleware.logging_middleware import RequestLoggingMiddleware
from app.db.session import engine, dispose_engine
from app.db import models as db_models

logger = logging.getLogger(__name__)

WORKER_ID = str(os.getpid())


# ── Callbacks ──────────────────────────────────────────────────────────────────

async def _on_promotion(event: PromotionEvent) -> None:
    """Called by watcher when a better ref is found. Switches loader ref."""
    logger.warning("Promotion: %s → %s (reason=%s worker=%s)",
                   event.previous, event.current, event.reason, WORKER_ID)
    await registry.get_loader().set_ref(event.current.name, reason=event.reason)


async def _on_config_change(new_config: PlacementConfig, ref: str) -> None:
    """Called when config file content actually changes (not just ref switch)."""
    logger.warning("Config content updated (ref=%s worker=%s envs=%s)",
                   ref, WORKER_ID, list(new_config.environments.keys()))


async def _on_notify(data: dict) -> None:
    """
    Called when this worker receives a PostgreSQL NOTIFY from another worker.
    The other worker already fetched the new config — we just need to reload ours.
    """
    new_ref = data.get("ref", registry.get_loader().active_ref)
    reason  = data.get("reason", "cross-worker-notify")

    logger.info("Cross-worker NOTIFY received (from=%s ref=%s worker=%s)",
                data.get("from_worker"), new_ref, WORKER_ID)

    loader = registry.get_loader()
    # Switch ref if it changed
    if new_ref != loader.active_ref:
        loader._ref = new_ref

    await loader.refresh(force=True)


# ── Lifespan ───────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    logger.info("Worker starting (pid=%s)", WORKER_ID)

    # ── 1. Release watcher (optional — only for versioned strategies) ──────────
    use_watcher = settings.github_config_strategy not in (
        ConfigStrategy.TRACK_BRANCH, ConfigStrategy.PINNED
    )

    watcher:     ReleaseWatcher | None = None
    initial_ref: str                   = settings.github_ref

    if use_watcher:
        watcher = ReleaseWatcher(
            owner            = settings.github_owner,
            repo             = settings.github_repo,
            strategy         = settings.github_config_strategy,
            semver_range     = settings.github_semver_range,
            allow_prerelease = settings.github_allow_prerelease,
            poll_interval    = settings.release_poll_interval,
            token            = settings.github_token,
            on_promote       = _on_promotion,
        )
        initial_ref_obj = await watcher.start()
        initial_ref     = initial_ref_obj.name
        logger.info("Watcher selected ref: %s (worker=%s)", initial_ref, WORKER_ID)

    # ── 2. Config loader ────────────────────────────────────────────────────────
    loader = GitHubConfigLoader(
        owner            = settings.github_owner,
        repo             = settings.github_repo,
        path             = settings.github_config_path,
        ref              = initial_ref,
        token            = settings.github_token,
        ttl              = settings.config_ttl,
        refresh_interval = settings.config_refresh_interval,
        on_change        = _on_config_change,
    )

    # ── 3. PostgreSQL sync bus ─────────────────────────────────────────────────
    sync_bus = ConfigSyncBus(
        database_url    = settings.database_url,
        on_notify       = _on_notify,
        worker_id       = WORKER_ID,
        reconnect_delay = 5.0,
    )

    registry.init(loader, sync_bus, watcher)

    # Start loader first (needs config before bus can use it)
    await loader.start()

    # Then start the sync bus (listen for other workers' changes)
    await sync_bus.start()

    # ── 4. DB ──────────────────────────────────────────────────────────────────
    async with engine.begin() as conn:
        await conn.run_sync(db_models.Base.metadata.create_all)

    logger.info("Worker ready (pid=%s ref=%s)", WORKER_ID, loader.active_ref)

    yield

    # ── Shutdown ────────────────────────────────────────────────────────────────
    logger.info("Worker shutting down (pid=%s)", WORKER_ID)
    if watcher:
        await watcher.stop()
    await loader.stop()
    await sync_bus.stop()
    await dispose_engine()
    stdlib_logging.shutdown()


# ── App factory ────────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title="Placement Decision Engine",
        version=settings.app_version,
        docs_url="/docs" if settings.app_env != "production" else None,
        redoc_url=None,
        lifespan=lifespan,
    )

    app.add_middleware(CORSMiddleware,
        allow_origins=["*"], allow_methods=["*"],
        allow_headers=["*"], expose_headers=["X-Request-ID"])
    app.add_middleware(RequestLoggingMiddleware)

    @app.exception_handler(Exception)
    async def _eh(request: Request, exc: Exception):
        logger.error("Unhandled exception", extra={"error": str(exc)}, exc_info=True)
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})

    from app.api.health    import router as health_router
    from app.api.placement import router as placement_router
    from app.api.config    import router as config_router

    app.include_router(health_router,    prefix="/v1",           tags=["Health"])
    app.include_router(placement_router, prefix="/v1/placement", tags=["Placement"])
    app.include_router(config_router,    prefix="/v1/config",    tags=["Config"])

    return app


app = create_app()
